import java.util.Iterator;


public interface BKIterator<E> extends Iterator<E>{
   
    /**
     * @param x             element for change
     * @return              returns element and before
     */
    E set(E data);
}