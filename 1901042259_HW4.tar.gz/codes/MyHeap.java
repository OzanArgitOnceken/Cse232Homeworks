import java.util.ArrayList;

public class MyHeap <E extends Comparable<E>>{
	private ArrayList <E>data;
	private ArrayList<occurances<E>>occur;
	private int size;
	/**
	 * creates MyHeap 
	 */
	public MyHeap() {
		data=new ArrayList<E>();
		occur=new ArrayList<occurances<E>>();
		size=0;
	} 
	/**
	 * @param pos takes integer position of array
	 * @return returns true if position equals leaf
	 * I did not use this method but it can be necessary
	 */
	private boolean isLeaf(int pos){
        if (pos > (size / 2) && pos <= size)
        	return true;
        return false;
    }
  
	/**
	 * @param pos 	current position of data
	 * @return 		returns integer value which indicates parent node's data
	 */
	private int parent(int pos) { return pos / 2; }
	  /**
	   * @param pos position of current data
	   * @return 	position of left node's position if current is 0 returns 0(itself)
	   */
    private int leftChild(int pos){ 
    	if(pos==0)
    		return 1;
    	return (2 * pos);
    	}
    /**
	 *@param pos 	position of current data
	 *@return 		position of right node's position
     */
    private int rightChild(int pos){return (2 * pos) + 1;}
    /**
     * @param fpos	first position
     * @param spos	second position
     */
    private void swap(int fpos, int spos){
        E temp= data.get(fpos);
        data.set(fpos, data.get(spos));
        data.set(spos, temp);
    }
    /**
     * @param element element for add in heap
     */
    public void insert(E element){
        boolean isOccur=false;
        for(int i=0;i<occur.size();i++) {
        	if(occur.get(i).compareTo(element)==0){
        		occur.get(i).increment();
        		isOccur=true;
        	}
        }
        if(isOccur==false)
        	occur.add(new occurances<E>(element));
        if(isExists(element)==false) {
        	data.add(element);
        	int current = size;
            while (data.get(current).compareTo(data.get(parent(current)))>0){
                swap(current, parent(current));
                current = parent(current);
            }
            size++;
        }
    }
    /**
     * @return 			returns the first data (biggest) in the heap
     */
    public E peek(){
    	return data.get(0);
    }
    /**
     * @param element	element for searching
     * @param current	current value of element (usually sending 0 from other methods)	
     */
    private int searchElement(E element,int current,int retval) {
    	if(data.get(current).compareTo(element)==0) {
        	return current;
    	}
    	else if(current<size) {
    		if(rightChild(current)<size)
    			retval=searchElement(element,rightChild(current),retval);
    		if(current!=0&&leftChild(current)<size)
    			retval=searchElement(element,leftChild(current),retval);
    	}
    	return retval;
    }
    /**
     * if the sended retval value equals at the starting point item does not exists
     * @param element 	element for search
     * @return 			returns true if exists
     */
    public boolean isExists(E element) {
    	if(size==0)
    		return false;
    	if(searchElement(element,0,-1)==-1)
    		return false;
    	return true;
    }
    /**
     * @param index		index represents the which biggest element
     * @return			returns removed element
     */
    public E remove(int index) {
    	E forReturn=null;
        if(index < 1 || index > size)
            throw new ArrayIndexOutOfBoundsException();
        if(size > 0){
            ArrayList<E> temp = new ArrayList<>();
            for(int i=0; i<size; i++){
                temp.add(data.get(i));
            }
            temp.sort(null);
            int elementThere=searchElement(temp.get(temp.size()-index),0,0);
            swap(elementThere,size-1);
            forReturn=data.get(size-1);
            data.remove(--size);
            findMyWay(elementThere);
            size--;
            for(int i=0;i<occur.size();i++) {
            	if(occur.get(i).compareTo(forReturn)==0)
            		occur.get(i).decrease();
            }
        }
        return forReturn;
    }

    /**
     * @param item		item is the removed data from heap
     * @return			returns removed elements position
     */
    public int remove(E item) {

        int elementThere=searchElement(item,0,0);
        int numOfOc = 0;
        for(int i=0;i<occur.size();i++) {
        	if(occur.get(i).compareTo(item)==0) {
        		occur.get(i).decrease();
        		numOfOc=occur.get(i).getOccurance();
        		if(occur.get(i).getOccurance()==0)
        		{
        			swap(elementThere,size-1);
        			data.remove(--size);
        			findMyWay(elementThere);
        			size--;
        		}
        	}
        }
        return numOfOc;
    }
    /**
     * this method locates the current data for true position
     * @param x		x is the position of data which wanted to locate at true position
     */
    private void findMyWay(int x) {
    	while(true) {
    		if(leftChild(x)<size-1&&data.get(x).compareTo(data.get(leftChild(x)))<0) {
    			swap(x,leftChild(x));
    			x=leftChild(x);
    		}
    		else if(rightChild(x)<size-1&&
    				data.get(rightChild(x)).compareTo(data.get(leftChild(x)))>0
    				&&data.get(x).compareTo(data.get(rightChild(x)))<0) {
    			swap(x,rightChild(x));
    			x=rightChild(x);
    		}
    		else
    			break;
    	}
    }
    /**
     * @param data		data for search how many existed in heap
     * @return			returns how many existed in heap
     */
    public int howManyOccurs(E data) {
    	for(int i=0;i<occur.size();i++) {
    		if(occur.get(i).compareTo(data)==0)
    			return occur.get(i).getOccurance();
    	}
    	return 0;//does not occurs
    }
    /**
     * @return			returns true if heap is empty
     */
    public boolean isEmpty() {
    	return size==0;
    }
    /**/
    public void merge(MyHeap<E> other) {
    	int i=0;
    	while(i<other.data.size()) {
    		this.insert(other.data.get(i));
    		i++;
    	}
    }
    /**
     * 
     * @param other         data for compare
     * @return              returns -1 if this.first element bigger than other returns 0 if both are same,else returns -1
    */
    public int compareTo(E other) {
    	if(data.get(0).compareTo(other)>0)
    		return -1;
    	else if(data.get(0).compareTo(other)==0)
    		return 0;
    	return 1;
    }
    /**
     * @return              returns string that implements all data about heap
     */
    public String toString() {
    	return data.toString()+"=>"+occur.toString();
    }
    /**
     * 
     * @return              returns the size of heap
    */
    public int size() {
    	return size;
    }

    /**
     * 
     * @param x             occurance for change
     * @return              returns mode of heap as occurance
    */
    public occurances<E> mode(occurances<E> x) {
    	occurances<E> temp=findMode();
    	if(temp.muchRepetition(x))
    		x=temp;
    	for(int i=0;i<occur.size();i++) {
    		if(x.compareTo(occur.get(i).getData())==0) {
    			x.increment();
    		}
    	}
    	return x;
    }
    /**
     * 
     * @return              returns mode of heap as ocurrance
    */
    public occurances<E> findMode() {
    	occurances<E> temp=new occurances<E>();
    	for(int i=0;i<occur.size();i++) {
    		if(occur.get(i).muchRepetition(temp))
    			temp=occur.get(i);
    	}
    	return temp;
    }
    
    

    private class HeapIterator implements BKIterator<E>{

        private int iter;
        private E lastReturned;
        /**
         * constructor of iterator
         */
        public HeapIterator(){
            iter = 0;
        }

        /**
         *  @return             returns true if iterator has next
         */
		@Override
		public boolean hasNext() {
			return iter<size;
		}

        /**
         * @return              returns element and goes next
         */
		@Override
        public E next() {
			if(hasNext())
				lastReturned=data.get(iter++);
			return lastReturned;
		}
        /**
         * @param x             element for change
         * @return              returns element and before
         */
		@Override
		public E set(E x) {
			lastReturned=data.get(iter);
			data.set(iter, x);
			findMyWay(iter);
			return lastReturned;
		}
    	
    }
    /**
     * 
     * @return                  returns an iterator
    */
    public BKIterator<E> iterator(){
        return new HeapIterator();
    }
    
}