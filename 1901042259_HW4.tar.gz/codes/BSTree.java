public class BSTree <E extends Comparable<E>>{
	
	private Node<E> head;
	private static class Node<E extends Comparable<E>>{
		
		private Node<E> right;
		private Node <E>left;
		private MyHeap<E> heap;
		/**
		 * constructor of node
		 */
		public Node(){
			this.right=null;
			this.left=null;
			heap=new MyHeap<E>();
		}
		/**
		 * @param data takes data for nodes data
		 */
		public Node(E data) {
			this.left=null;
			this.right=null;
			heap=new MyHeap<E>();
			heap.insert(data);
		}
		/**
		 * @return 				returns false if size is not fulled else returns true
		 */
		private boolean isFulled() {
			if(heap.size()<7)
				return false;
			return true;
		}
		/**
		 * @param data			data for adding to the heap
		 */
		private void add(E data) {
			this.heap.insert(data);
        }
        /**
         * 
         * @param data          data for compare
         * @return              returns -1 if heaps firs element smaller than data returns 0 if they are same else it returns 1
        */
		private int compareTo(E data) {
			if(heap.compareTo(data)<0)
				return -1;
			else if(heap.compareTo(data)==0)
				return 0;
			else
				return 1;
		}
	}
	/**
     * constructor of BSTree
     */
	public BSTree() {
		head=new Node<E>();
    }
    /**
     * 
     * @param data          data for adding to BSTree
    */
	public void add(E data) {
		if(!head.isFulled())
			head.add(data);
		else {
			Node<E> temp=head;
			while(true) {
				if(temp.compareTo(data)<0){
					if(!temp.isFulled()) {
						temp.heap.insert(data);
						break;
					}
					else if(temp.left==null) {
						temp.left=new Node<E>(data);
						break;
					}
					else
						temp=temp.left;					
				}
				else if(temp.compareTo(data)>0) {
					if(!temp.isFulled()) {
						temp.heap.insert(data);
						break;
					}
					if(temp.right==null) {
						temp.right=new Node<E>(data);
						break;
					}
					else
						temp=temp.right;
				}
				else {
					temp.add(data);
					break;
				}
			}
			
		}
		
    }
    /**
     * 
     * @param item          item for remove from tree
     * @return              returns the occurance of item
    */
	public int remove(E item) {
		Node<E>temp=head;
		int forReturn=0;
		while(true) {
			if(temp.heap.isExists(item)) {
				forReturn=temp.heap.remove(item);
				if(temp.heap.size()==0)
					if(temp.left!=null)
						wayFinderLeft(temp);
					else if(temp.right!=null)
						wayFinderRight(temp);
					else
						temp=null;
				break;
			}
			if(temp.compareTo(item)<0) {
				if(temp.left!=null)
					temp=temp.left;
				else
					break;
			}
			else if(temp.compareTo(item)>0)
				if(temp.right!=null)
					temp=temp.right;
				else 
					break;
		}
		return forReturn;
    }
    /**
     * This method helps to the remove method 
     * This method goes rightest of the node and change with the current for help deleting
     * @param temp              removed node
    */
	private void wayFinderLeft(Node<E> temp) {
		Node<E> iter=temp;
		while(temp.right!=null) {
			if(iter.right==null) {
				temp.heap=iter.heap;
				if(iter.left!=null)
					iter=iter.left;
				else
					iter=null;
			}
			if(iter.right!=null)
				iter=iter.right;
		}		
	}
    /**
     * This method helps to the remove method 
     * This method goes leftest of the node and change with the current for help deleting
     * @param temp              removed node
    */
	private void wayFinderRight(Node<E> temp) {
		Node<E> iter=temp;
		while(temp.left!=null) {
			if(iter.left==null) {
				temp.heap=iter.heap;
				if(iter.right!=null)
					iter=iter.right;
				else
					iter=null;
			}
			if(iter.left!=null)
				iter=iter.left;
		}
    }
    /**
     * 
     * @param data          data for find
     * @return              returns the occurance value
    */
	public int find(E data) {
		Node<E>temp=head;
		while(true) {
			if(temp.heap.isExists(data))
				return temp.heap.howManyOccurs(data);
			else {
				if(temp.compareTo(data)<0) {
					if(temp.left!=null)
						temp=temp.left;
					else
						break;
				}
				else if(temp.compareTo(data)>0) {
					if(temp.right!=null)
						temp=temp.right;
					else
						break;
				}
				else
					break;
			}
		}
		return -1;//if not exists
    }
    /**
     * @return              Returns the string of binary search tree(like binary style)
     */
	public String toString() {
		Node<E>temp=head;
		StringBuilder x=new StringBuilder();
		return recString(temp,x,0);
    }
    /**
     * this is a helper recursive Function of toString
     * @param temp          temporary starting node(usually head node)
     * @param str           string that holds data
     * @param i             space holder (usually 0)
     * @return              returns the string of data
    */
	public String recString(Node<E> temp,StringBuilder str,int i) {
		for(int j=0;j<i;j++)
			str.append("  ");
		str.append(temp.heap+"\n");
		if(temp.left!=null) 
			recString(temp.left,str,i+1);
		if(temp.right!=null)
			recString(temp.right,str,i+1);
		return str.toString();
    }
    /**
     * @return              returns the string that includes informations about mode of tree
    */
	public String findMode() {
		Node<E>temp=head;
		occurances<E>oc=new occurances<E>();
		oc=findModeRec(oc,temp);
		return "Mode element of tree: "+oc.getData().toString()+" and it occurs "+(oc.getOccurance()-1)+" times";
    }
    
    /**
     * 
     * this is a helper recursive function of findMode
     * @param oc            holds occurances of binary tree
     * @param temp          starting node(usually headNode)
     * @return              returns the occurance for findMode
    */
	private occurances<E> findModeRec(occurances<E> oc,Node<E>temp) {
		if(temp.left!=null) 
			oc=findModeRec(oc,temp.left);
		if(temp.right!=null) 
			oc=findModeRec(oc,temp.right);
		return temp.heap.mode(oc);
	}
}