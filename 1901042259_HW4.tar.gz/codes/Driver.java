import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;


public class Driver {
	public static void main(String args[]) {
		System.out.println("\t\t.: PART 1 :.");
		MyHeap<Integer> pQue=new MyHeap<Integer>();
		pQue.insert(10);
		pQue.insert(20);
		pQue.insert(30);
		pQue.insert(40);
		pQue.insert(50);
		pQue.insert(3);
		pQue.insert(100);
		System.out.println("After adding some integers:(after => means the occurances)\n"+pQue);
		

        System.out.println("Searching an element from Priority Queue which is contained(50)");
        System.out.println(pQue.isExists(50));

        System.out.println("Searching an element from Priority Queue which is not contained(50)");
        System.out.println(pQue.isExists(-50));

		MyHeap<Integer> pQue2=new MyHeap<Integer>();
		pQue2.insert(42);
		pQue2.insert(32);
		pQue2.insert(112);
		System.out.println("Creating a new priority queue.");
		System.out.println("New queue (pQue2)="+pQue2);
		
		pQue.merge(pQue2);
		System.out.println("After Merge pQue:");
		System.out.println(pQue);

		System.out.println("After Merge pQue2:");
		System.out.println(pQue);
		System.out.println("Adding same data to pQue(112)");
		pQue.insert(112);
		System.out.println(pQue);
		System.out.println("Now removing second biggest element:");
		pQue.remove(2);
		System.out.println(pQue);

        System.out.println("\nTesting queue's iterator with the set method");

        BKIterator<Integer> iter = pQue.iterator();
    	System.out.print(iter.next()+"=>");
    	System.out.print(iter.next()+"=>");
    	iter.set(35);
        while(iter.hasNext()) {
        	System.out.print(iter.next()+"=>");
        }
        System.out.println();
        System.out.println("This is new pQue:\n"+pQue);
        System.out.println("\n\n\t\t\t.: Part 2 :.##\n");
		
        

        ArrayList<Integer> array = new ArrayList<>();
        Random random = new Random();
        BSTree<Integer> tree = new BSTree<Integer>();
        for(int i=0; i<50; ++i){
            int num = random.nextInt(50);
            array.add(num);
            tree.add(num);
        }


        System.out.println("\nMax Heap Binary Search Tree:\n");
        System.out.println(tree);
		

		System.out.println("Sometimes array can not find exact because for example there are 2 different integers same times");
		
	    Collections.sort(array);
	    Collections.reverse(array);
	    System.out.println("Sorted array:");
	    System.out.println(array);
		
		System.out.println("This mode came from array:"+mode(array));
		System.out.println(tree.findMode());
		
		System.out.println("Searching not existed element in tree");
		for(int i=-1;i>-11;i--) {
			int howMany=tree.find(i);
			if(howMany<0)
				System.out.println("There are no number like "+i);
			else
				System.out.println("Tree has "+howMany+" times "+i);
		}
		System.out.println("Searching existed element in tree");
		for(int i=0;i<array.size();i++) {
			int howMany=tree.find(array.get(i));
			if(howMany<0)
				System.out.println("There are no number like "+array.get(i));
			else
				System.out.println("Tree has "+howMany+" times "+array.get(i));			
		}
		System.out.println("Before deleting items from tree:");
		System.out.println(tree);
		for(int i=0;i<10;i++)
			tree.remove(array.get(i));
		System.out.println("After delete");
		System.out.println(tree);
		System.out.println("Deleting an nonexisted item(-30)");
		tree.remove(-30);
		System.out.println(tree);
	}
	public static int mode(ArrayList<Integer> arr) {
        int maxValue = 0, maxCount = 0;

        for (int i = 0; i < arr.size(); ++i) {
            int count = 0;
            for (int j = 0; j < arr.size(); ++j) {
                if (arr.get(j) == arr.get(i)) ++count;
            }
            if (count > maxCount) {
                maxCount = count;
                maxValue = arr.get(i);
            }
        }
        return maxValue;
    }
}