public class occurances <E extends Comparable<E>>{
	private E data;
	private int occurance;
	/**
	 * creates an occurance and sets data to null
	 */
	public occurances() {
		data=null;
		occurance=0;
	}
	/**
	 * @param data 		sended generic data for this.data
	 */
	public occurances(E data) {
		this.data=data;
		occurance=1;
	}
	
	/**
	 * this methods compare the datas 
	 * @param x 		data for compare
	 * @return			returns 0 if x and this.data equals returns 1 if this.data>x else returns -1
	 */
	public int compareTo(E x) {
		if(data.compareTo(x)==0)
			return 0;
		if(data.compareTo(x)<0)
			return -1;
		else
			return 1;
	}
	/**
	 *	@param other	other data for compare
	 *	@return			returns true if this.occurance > other.orccurance
	 */
	public boolean muchRepetition(occurances<E> other){
		return this.occurance>other.occurance;
	}

	/**
	 * increases occurance
	 */
	public void increment(){occurance++;}
	/**
	 * decreases occurance
	 */
	public void decrease(){occurance--;}
	/**
	 * @return 			returns the occurance
	 */
	public int getOccurance(){return occurance;}
	/**
	 * @return 			returns the data
	 */
	public E getData(){return data;}
	/**
	 * @param data		data for set this.data
	 */
	public void setData(E data){this.data=data;}
	/**
	 * @param occurance	sets occurance for this.occurance
	 */
	public void setOccurance(int occurance){this.occurance=	occurance;}
	/**
	 * @return			returns the string of occurance
	 */
	public String toString() {
		return new String("["+data+","+occurance+"]");
		
	}
}