import java.util.ArrayList;
/** implements the recursive merge sort algorithm. in this version, copies 
of the sub.tables are made, sorted, and then merged.
*/
public class MergeSort {
	
	private static int myCompare(Product a,Product b) {

		Integer x = Integer.parseInt(a.getPrice().trim());
		Integer y = Integer.parseInt(b.getPrice().trim());
		return x.compareTo(y);
	}
	/** Sort the array using the merge sort algorithm.
	post: table is sorted.
	@param table The array to be sorted
	 */ 
	public static <T extends Comparable<T>> void sort(ArrayList<T> table) {
		// A table with one element is sorted already.
		if (table.size()> 1) {
			// Split table into halves.
			int halfSize = table.size()/2;
			ArrayList<T> leftTable =new ArrayList<T>();
			int i=0;
			for(;i<halfSize;++i) {
				leftTable.add(table.get(i));
			}
			ArrayList<T> rightTable = new ArrayList<T>();
			for(;i<table.size();++i) {
				rightTable.add(table.get(i));
			}
			// Sort the halves.
			sort(leftTable);
			sort(rightTable);
			// Merge the halves.
			merge(table, leftTable, rightTable);
		}
	}
	// See Listing 8.4 for the merge method.
	/** Merge two sequences.
	@post outputSequence is the merged result and is sorted.
	@param outputSequence The destination
	@param leftSequence The left input
	@param rightSequence The right input
	 */
	private static <T extends Comparable<T>> void merge(ArrayList<T> outputSequence,
			ArrayList<T>leftSequence,
			ArrayList<T> rightSequence) { 
		int i = 0; 
		// index into the left input sequence.
		int j = 0; 
		// index into the right input sequence.
		int k = 0; 
		while (i < leftSequence.size() && j < rightSequence.size()) {
			if (myCompare((Product)leftSequence.get(i),(Product)rightSequence.get(j)) < 0) {
				outputSequence.set(k++, leftSequence.get(i++));
			} else {
				outputSequence.set(k++, rightSequence.get(j++));
			}
		}
		while (i < leftSequence.size()) {
			outputSequence.set(k++, leftSequence.get(i++));
		}
		// Copy remaining input from right sequence into output.
		while (j < rightSequence.size()) {
			outputSequence.set(k++, rightSequence.get(j++));
		}
	}
}