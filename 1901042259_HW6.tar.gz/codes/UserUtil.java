import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Hashtable;
import java.util.Scanner;

public class UserUtil {
	private static Hashtable<String, String> users = new Hashtable<String, String>();
	public static void readUsersFromFile(){
		try {
			Scanner in = new Scanner(new FileReader("src/Users.txt"));
			
			while (in.hasNextLine()) {
				String line = in.nextLine();
				String[] temp = line.split(" "); 
				users.put(temp[0], temp[1]);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	public static int loginUser(String id, String password){
		try {String s = users.get(id);
			if (s != null && s.equals(password)) {
				Scanner in = new Scanner(new FileReader("src/Users.txt"));
				
				while (in.hasNextLine()) {
					String line = in.nextLine();
					String[] temp = line.split(" "); 
					if (id.equals(temp[0])) {
						if (temp[2].equals("Customer"))
							return 1;
						else if (temp[2].equals("Trader"))
							return 2;
					}
				}
			} 
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}
			
		return 0;
		
	}
	public static String findUserId(String name){
		try {Scanner in = new Scanner(new FileReader("src/Users.txt"));
			while (in.hasNextLine()) {
				String line = in.nextLine();
				String[] temp = line.split(" ");
				if (temp[3].equals(name))
					return temp[0];
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
	public static String findUserName(String id){
		try {
			Scanner in = new Scanner(new FileReader("src/Users.txt"));
			
			while (in.hasNextLine()) {String line = in.nextLine();
			
			String[] temp = line.split(" "); 
			
				if (temp[0].equals(id))
					return temp[3];
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
	
}