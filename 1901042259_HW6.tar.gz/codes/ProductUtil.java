import java.util.*;
import java.io.*;

public class ProductUtil {
	
	public static void readProductsFromFile(){try {
			PriorityQueue<Product> products = new PriorityQueue<Product>(Product.getNameComp());
			BufferedReader br = new BufferedReader(new FileReader("src/e-commerce-samples.csv"));
			String line;
			boolean flag = false;
			
			while ((line = br.readLine()) != null) {
				if (flag == false) {flag = true;continue;}
				
				String[] pStr = line.split(";");
				
				products.add(new Product(pStr[0],pStr[1], pStr[2], pStr[3], pStr[4], pStr[5], pStr[6]));
			}
			
			File outputFile = new File("src/Products.txt");
			FileWriter setObj = new FileWriter(outputFile);
			
			while (!products.isEmpty())
				setObj.write(products.poll().toString());
			
			setObj.close();
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void searchFromFile(ArrayList<Product> searchedProducts, String str, int option)
	{
		try {BufferedReader br = new BufferedReader(new FileReader("src/Products.txt"));
			String line;
			
			while ((line = br.readLine()) != null) {
			
				
				String[] pStr = line.split(";");
				
				
				if (pStr[1].contains(str) || pStr[5].contains(str)) 
					searchedProducts.add(new Product(pStr[0],pStr[1], pStr[2], pStr[3], pStr[4], pStr[5], pStr[6]));
				
				
			}
			
			searchSortHelper(searchedProducts, option);
			
			br.close();
			
			for (int i = 0; i < searchedProducts.size(); ++i) {
				System.out.println(searchedProducts.get(i));
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	private static void searchSortHelper(ArrayList<Product> searchedProducts, int option)
	{
		if (1 == option) {
			
			ShellSort.sort(searchedProducts);
			
		}
		else if (2 == option) {
			
			MergeSort.sort(searchedProducts);
			
		}
		else if (3 == option)  {	
			
			HeapSort.sort(searchedProducts);
			
		}
		
		
	}
	public static void searchSort(ArrayList<Product> searchedProducts, int option)
	{
		searchSortHelper(searchedProducts, option);
		
		for (int i = 0; i < searchedProducts.size(); ++i)
			System.out.println(searchedProducts.get(i));
	}
	public static void searchFromFile(String str){
		try {
			BufferedReader br = new BufferedReader(new FileReader("src/Products.txt"));
			String line;
			
			TreeSet<Product> myTree = new TreeSet<Product>();
			
			while ((line = br.readLine()) != null) {
				String[] pStr = line.split(";");
				
				if (pStr[6].contains(str)) 
					myTree.add(new Product(pStr[0],pStr[1], pStr[2], pStr[3], pStr[4], pStr[5], pStr[6]));
			}
			
			br.close();
			while (!myTree.isEmpty())
				System.out.println(myTree.pollFirst().toString());
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void filterPrice(ArrayList<Product> searchedProducts, String str, int choice, int bound)
	{
		searchSortHelper(searchedProducts, 2);
		for (int i = 0; i < searchedProducts.size(); ++i) {
			int price = Integer.parseInt(searchedProducts.get(i).getPrice().trim());
			if ((choice == 1 && price > bound) || (choice == 2 && price < bound))
				System.out.println(searchedProducts.get(i));
		}	
	}
	
	public void filterPrice(ArrayList<Product> searchedProducts, String str, int choice, int boundLower, int boundUpper)
	{
		searchSortHelper(searchedProducts, 2);
		for (int i = 0; i < searchedProducts.size(); ++i) {
			int price = Integer.parseInt(searchedProducts.get(i).getPrice().trim());
			if (choice == 3 && price > boundLower && price < boundUpper)
				System.out.println(searchedProducts.get(i));
		}
	}
	private static void createFile(ArrayList<Product> products, File file){
		try {
			FileWriter setObj = new FileWriter(file);
			
			for (int i = 0; i < products.size(); ++i) 
				setObj.write(products.get(i).toString());

			setObj.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void printAllProducts(ArrayList<Product> pList)
	{	
		for (int i = 0; i < pList.size(); ++i) 
			System.out.println(pList.get(i));
	}
	public static void addProduct(Product p, String file)
	{
		try {
			FileWriter fw = new FileWriter(file, true);
			fw.write(p.toString());
			fw.close();
		} catch(IOException e) {
			e.printStackTrace();
		}		
	}
	public static void deleteAProduct(String productId){
		try {
			File inputFile = new File("src/Products.txt");
			File tempFile = new File("src/Temp.txt");
			ArrayList<Product> searchedProducts = new ArrayList<Product>();
			BufferedReader br = new BufferedReader(new FileReader(inputFile));
			String line;
			
			while ((line = br.readLine()) != null) {
				
				String[] pStr = line.split(";");
				
				if (!pStr[0].equals(productId)) 
					searchedProducts.add(new Product(pStr[0],pStr[1], pStr[2], pStr[3], pStr[4], pStr[5], pStr[6]));
				
			}
			
			br.close();
			createFile(searchedProducts, tempFile);
			inputFile.delete();
			tempFile.renameTo(inputFile);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void productEdit(String id){
		try {
			File inputFile = new File("src/Products.txt");
			File tempFile = new File("src/Temp.txt");
			ArrayList<Product> searchedProducts = new ArrayList<Product>();
			BufferedReader br = new BufferedReader(new FileReader(inputFile));
			String line;
			Scanner kb = new Scanner(System.in);
			boolean flag = false;
			
			while ((line = br.readLine()) != null) {
				
				String[] pStr = line.split(";");
				
				if (pStr[0].equals(id)) {
					flag = true;
					System.out.printf("What do you want to change for product?");
					System.out.println("1-> Name");
					System.out.println("2-> Price");
					System.out.println("3-> Discounted price");
					System.out.println("4-> Description");
					int choice = Integer.parseInt(kb.nextLine());

					if (1 == choice) {
						System.out.println("Enter new name : ");
						String s = kb.nextLine();
						pStr[1] = s;
					}
					else if (2 == choice) {
						System.out.println("Enter new price : ");
						String price = kb.nextLine();
						pStr[3] = price;
					}
					else if (3 == choice) {
						System.out.println("Enter new discounted price : ");
						String price = kb.nextLine();
						pStr[4] = price;
					}
					else if (4 == choice) {
						System.out.println("Enter new description: ");
						String description = kb.nextLine();
						pStr[5] = description;
					}					
				}
				searchedProducts.add(new Product(pStr[0],pStr[1], pStr[2], pStr[3], pStr[4], pStr[5], pStr[6]));
			}
			br.close();
			if (flag == false) {
				System.out.println("There is no id like that");
				return;
			}
			
			
			searchSortHelper(searchedProducts, 1);
			
			createFile(searchedProducts, tempFile);
			inputFile.delete();
			tempFile.renameTo(inputFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void filterTheCategory(ArrayList<Product> searchedProducts, String str, String category)
	{	
		for (int i = 0; i < searchedProducts.size(); ++i) 
			if (searchedProducts.get(i).getCategory().contains(category))
				System.out.println(searchedProducts.get(i));
		
	}
	public static void meetOrder(String userId, String productId){
		
		try {
			File file = new File("src/Orders.txt");
			if (!file.exists()) {
				System.out.println("Orders.txt doesn't exist.");
				return;
			}
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line;

			while ((line = br.readLine()) != null) {
				String[] oStr = line.split(" ");
				String id = UserUtil.findUserId(oStr[2]);
				if (id != null && id.equals(userId) && oStr[0].equals(productId)) {
					deleteAProduct(productId);
					System.out.println("Product sold");
					break;
				}
			}
			
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	public static void addAnOrder(ArrayList<Product> searchedProducts, String productId, String userId)
	{
		try {
			FileWriter fw = new FileWriter("src/Orders.txt", true);
			
			for (int i = 0; i < searchedProducts.size(); ++i) {
				Product p = searchedProducts.get(i); 
				if (p.getId().equals(productId)) {
					System.out.println("Order done");
					fw.write(String.format("%s %s %s%n", productId, userId, p.getTrader()));
					fw.close();
					return;
				}
			}
			fw.close();
			System.out.println("There is no id like that");
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	public static void seeOrder(String userId)
	{
		try {
			File file = new File("src/Orders.txt");
			if (!file.exists()) {
				System.out.println("Orders.txt doesn't exist.");
				return;
			}
			
			
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line;
			
			System.out.println("Product ID - User ID - Trader Name");
			
			while ((line = br.readLine()) != null) {
				String[] oStr = line.split(" ");
				String id = UserUtil.findUserId(oStr[2]);
				if (id != null && id.equals(userId))
					System.out.println(line);
			}
			
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void cancelOrder(String userId, String productId)
	{
		try {
			File file = new File("src/Orders.txt");
			File tempFile = new File("src/Temp.txt");
			if (!file.exists()) {
				System.out.println("Orders.txt doesn't exist.");
				return;
			}
			ArrayList<String> orderProducts = new ArrayList<String>();
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line;

			while ((line = br.readLine()) != null) {
				String[] oStr = line.split(" ");
				if (!oStr[0].equals(productId))
					orderProducts.add(line);
			}
			FileWriter setObj = new FileWriter(tempFile);
			
			for (int i = 0; i < orderProducts.size(); ++i) 
				setObj.write(orderProducts.get(i));

			setObj.close();
			br.close();
			file.delete();
			tempFile.renameTo(file);
			System.out.println("Product can not sold");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}