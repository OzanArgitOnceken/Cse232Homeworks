import java.util.Comparator;

public class Product implements Comparable<Product> {
	private String id;
	private String name;
	private String productCategory;
	private String price;
	private String discountedPrice;
	private String description;
	private String trader;
	
	public Product(){
		this("", "", "", "0", "0", "", "");
	}
	
	public Product(String id, String name, String productCategory, String price, String discountedPrice, String description, String trader){
		this.setId(id);
		this.setName(name);
		this.setProductCategory(productCategory);
		this.setPrice(price);
		this.setDiscountedPrice(discountedPrice);
		this.setDescription(description);
		this.setTrader(trader);
	}

	public String getId() {return id;}

	public void setId(String id) {this.id = id;}

	public String getName() {return name;}

	public void setName(String name) {this.name = name;}

	public String getPrice(){return price;}

	public void setPrice(String price){this.price = price;}

	public String getDiscountedPrice(){return discountedPrice;}

	public void setDiscountedPrice(String discountedPrice){this.discountedPrice = discountedPrice;}

	public String getDescription(){return description;}

	public void setDescription(String description){this.description = description;}

	public String getTrader(){return trader;}
	
	public void setTrader(String trader){this.trader = trader;}
	
	public String getCategory() {return productCategory;}
	
	public void setProductCategory(String productCategory){this.productCategory = productCategory;}
	
	public String toString(){return String.format("%s;%s;%s;%s;%s;%s;%s\n", id, name, productCategory, price, discountedPrice, description, trader);}

	public static NameComp getNameComp(){return new NameComp();	}
	public static PriceComp getPriceComp(){return new PriceComp();}

	@Override
	public int compareTo(Product o) {return getId().compareTo(o.getId());}
}

class NameComp implements Comparator { 
	@Override
    public int compare(Object o1, Object o2) {
        Product pr1,pr2;
        pr1 = (Product) o1;
        pr2 = (Product) o2;
        return pr1.getName().compareTo(pr2.getName());
    }
}

class PriceComp implements Comparator {
    @Override
    public int compare(Object o1, Object o2) {
        Product pr1,pr2;
        pr1 = (Product) o1;
        pr2 = (Product) o2;
        return pr1.getPrice().compareTo(pr2.getPrice());
    }
}

