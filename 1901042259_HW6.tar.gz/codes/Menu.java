import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
	public static void myMenu()
	{
		java.util.Scanner kb = new java.util.Scanner(System.in);
		
		while (true) {
			System.out.printf("Welcome to e-shopping application%n");
			System.out.printf("User Id: (-1 exit) ");
			String id = kb.nextLine();
			
			if (id.equals("-1"))
				break;
			
			System.out.printf("Password: ");
			String password = kb.nextLine();
			
			UsersMenus(id, password);
		}
		kb.close();
	}

	public static void UsersMenus(String id, String password){
		UserUtil.readUsersFromFile();
		int loginUser = UserUtil.loginUser(id, password);
		
		if (loginUser != 0)
			System.out.printf("Welcome %s%n%n", id);
		else {
			System.out.printf("Boyle bir kullanici bulunamadi%n%n");
			return;
		}
		
		ProductUtil.readProductsFromFile();
		
		if (loginUser == 2) 
			MenuForTrader(id);
		else 
			MenuForCustomer(id);
	}
	
	public static void MenuForTrader(String userId)
	{
		int choice;
		Scanner kb = new Scanner(System.in);
		
		do {
			System.out.println("1-> Add a product");
			System.out.printf("2-> Remove a product%n");
			System.out.printf("3-> Edit a product%n");
			System.out.printf("4-> See list of orders%n");
			System.out.printf("0-> Exit%n");
			choice = Integer.parseInt(kb.nextLine());
			if (0 == choice)
				return;
			else if (1 == choice) {
				Product p = new Product();
				System.out.printf("Please enter product's ID: ");
				p.setId(kb.nextLine());
				System.out.printf("Please enter product's name: ");
				p.setName(kb.nextLine());
				System.out.printf("Please enter product's category: ");
				p.setProductCategory(kb.nextLine());
				System.out.printf("Please enter product's price: ");
				p.setPrice(kb.nextLine());
				System.out.printf("Please enter product's discounted price: ");
				p.setDiscountedPrice(kb.nextLine());
				System.out.printf("Please enter product's description: ");
				p.setDescription(kb.nextLine());
				String name = UserUtil.findUserName(userId);
				if (name != null) 
					p.setTrader(name);
				ProductUtil.addProduct(p, "src/Products.txt");
			}
			else if (2 == choice) {
				System.out.printf("Silinmesini istediginiz urunun id'sini giriniz:");
				String id = kb.nextLine();
				ProductUtil.deleteAProduct(id);
			}
			else if (3 == choice) {
				System.out.printf("Degistirmek istediginiz urunun id'sini giriniz: ");
				String id = kb.nextLine();
				//System.out.printf("user.getId() = [%s]%n", user.getName());
				ProductUtil.productEdit(id);
			}
			else if (4 == choice) {
				System.out.printf("1) See List of Orders%n");
				System.out.printf("2) Meet Order%n");
				System.out.printf("3) Cancel Order%n");
				int traderChoice = Integer.parseInt(kb.nextLine());
				
				if (1 == traderChoice) {
					ProductUtil.seeOrder(userId);
				}
				else if (2 == traderChoice) {
					System.out.printf("Hangi id'deki urunun satisina onay veriyorsun?%n");
					String productId = kb.nextLine();
					ProductUtil.meetOrder(userId, productId);
				}
				else if (3 == traderChoice) {
					System.out.printf("Hangi id'deki urunun satisina onay vermiyorsun?%n");
					String productId = kb.nextLine();
					ProductUtil.cancelOrder(userId, productId);
				}
			}
		} while (choice != 0);
	}
	
	public static void MenuForCustomer(String userId){
		int choice;
		Scanner kb = new Scanner(System.in);
		
		do {
			System.out.printf("1) Search and query the product%n");
			System.out.printf("2) Display all the products of a trader%n");
			System.out.printf("0) Exit%n");
			choice = Integer.parseInt(kb.nextLine()); 
			if (0 == choice)
				break;
			if (1 == choice) {
				System.out.printf("Please enter a product name: ");
				String str = kb.nextLine();
				ArrayList<Product> searchedProducts = new ArrayList<Product>();
				ProductUtil pUtil = new ProductUtil();
				pUtil.searchFromFile(searchedProducts,str, 1);
				for (;;) {
					System.out.printf("1) Siralama%n");
					System.out.printf("2) Filtreleme%n");
					System.out.printf("3) Satin Alma%n");
					System.out.printf("0) Go to Menu%n");
					int option = Integer.parseInt(kb.nextLine());
					if (0 == option) {
						break;
					}
					else if (1 == option) {
						System.out.printf("Neye gore siralamak istersin%n");
						System.out.printf("1) Name%n");
						System.out.printf("2) Price%n");
						System.out.printf("3) Discount%n");	
						int a = Integer.parseInt(kb.nextLine());
						ProductUtil.searchSort(searchedProducts, a);
					}
					else if (2 == option) {
						System.out.printf("Neye gore filtrelemek istersiniz%n");
						System.out.printf("1) Fiyat%n");
						System.out.printf("2) Kategori%n");
						int a = Integer.parseInt(kb.nextLine());
						
						if (1 == a) {
							System.out.printf("1) Sadece alt fiyat%n");
							System.out.printf("2) Sadece ust fiyat%n");
							System.out.printf("3) Hem alt hem ust fiyat%n");
							int priceChoice = Integer.parseInt(kb.nextLine());
							
							if (1 == priceChoice) {
								System.out.printf("Lutfen alt fiyati giriniz: ");
								int price = Integer.parseInt(kb.nextLine());
								pUtil.filterPrice(searchedProducts,str, 1, price);
							}
							else if (2 == priceChoice) {
								System.out.printf("Lutfen ust fiyati giriniz: ");
								int price = Integer.parseInt(kb.nextLine());
								pUtil.filterPrice(searchedProducts,str, 2, price);
							}
							else if (3 == priceChoice) {
								System.out.printf("Lutfen alt fiyati giriniz: ");
								int priceOne = Integer.parseInt(kb.nextLine().trim());
								System.out.printf("Lutfen ust fiyati giriniz: ");
								int priceTwo = Integer.parseInt(kb.nextLine().trim());
								pUtil.filterPrice(searchedProducts,str, 3, priceOne, priceTwo);
							}
						}
						else if (2 == a) {
							System.out.printf("Lutfen bir kategori ismi girin%n");
							String category = kb.nextLine();
							ProductUtil.filterTheCategory(searchedProducts,str, category);
						}
					}
					else if (3 == option) {
						System.out.printf("Lutfen satin almak istediginiz urunun idsini giriniz: ");
						String productId = kb.nextLine();
						ProductUtil.addAnOrder(searchedProducts, productId, userId);
					}
				}
			}
			else if (2 == choice) {
				System.out.printf("Please enter a trader name: ");
				String str = kb.nextLine();
				ProductUtil.searchFromFile(str);
			}
		} while (choice != 0);
		
	}
}