import java.util.ArrayList;

/** implements the Shell sort algorithm. */
public class ShellSort {
	private static int myCompare(Product a, Product b){
		return a.getName().compareTo(b.getName());
	}
	/** Sort the table using Shell sort algorithm.
 	@post table is sorted.
 	@param table The array to be sorted
	 */
	public static <T extends Comparable<T>> void sort(ArrayList<T> table) {
		// Gap between adjacent elements.
		int gap = table.size() / 2;
		while (gap > 0) {
			for (int nextPos = gap; nextPos < table.size(); nextPos++) {
				// insert element at nextPos in its sub.array.
				insert(table, nextPos, gap);
			} // End for.
			// Reset gap for next pass.
			if (gap == 2) {
				gap = 1;
			} else {
				gap = (int) (gap / 2.2);
			}
		} // End while.
	} // End sort.
	/** inserts element at nextPos where it belongs in array.
 	@post Elements through nextPos in sub.array are sorted
 	@param table The array being sorted
 	@param nextPos The position of element to insert
 	@param gap The gap between elements in the sub.array
	 */
 private static <T extends Comparable<T>> void insert(ArrayList<T> table, 
		 int nextPos, int gap) {
		 	T nextVal = table.get(nextPos);
		 	// Element to insert.
		 	// Shift all values > nextVal in sub.array down by gap.
		 	while ((nextPos > gap - 1) && (myCompare((Product)nextVal,(Product)table.get(nextPos-gap)) < 0)) {
		 		// First element not shifted.
		 		table.set(nextPos,table.get(nextPos-gap));
		 		// Shift down.
		 		nextPos -= gap; 
		 		// Check next position in sub array.
		 	}
		 	table.set(nextPos, nextVal);
		 	// insert nextVal.
	}
}