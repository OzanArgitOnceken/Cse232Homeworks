import java.util.Scanner;

public class Furniture implements BasicFurniture{

    int model;
    int color;
    String furnitureClass;
    /**
     * Default constructor
     */
    public Furniture(){
        System.out.println("Enter furniture class");
        Scanner input=new Scanner(System.in);
        this.furnitureClass=input.nextLine();
        setModel(1);
        setColor(1);
    }

    /**
     * if model and color fits creates
     * else creates model and color to 1
     * @param classString chair or office desk or..(string)
     * @param model int model
     * @param color int color
    */
    public Furniture(String classString,int model,int color){
        this.furnitureClass=classString;
        try {
            if(classString.equals("Chair")){
                if(model<0||model>7)
                    model=1;
                if(color<0||color>5)
                    color=1;
                setModel(model);
                setColor(color);
            }else if(classString.equals("Office Desk")){
                if(model<0||model>=5)
                    model=1;
                if(color<0||color>4)
                    color=1;
                setModel(model);
                setColor(color);
            }else if(classString.equals("Bookcase")){
                if(model<0||model>12)
                    model=1;
                setModel(model);
                setColor(0);
            }else if(classString.equals("Cabinet")){
                if(model<0||model>12)
                    model=1;
                setModel(model);
                setColor(0);
            }else if(classString.equals("Meeting Table")){
                if(model<0||model>=10)
                    model=1;
                if(color<0||color>4)
                    color=1;
                setModel(model);
                setColor(color);
            }
            else{
                throw new MyException("Wrong input");
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }


    }



    @Override
	public void setModel(int model){
        this.model=model;
    }

    @Override
    public void setColor(int color){
        this.color=color;
    }

    @Override
    public int getModel(){
        return this.model;
    }

    @Override
    public int getColor() {
        return this.color;
    }
    
    /**
     *prints chair or office desk or....
     *prints model and color 
     */
    public void printFurniture(){
        System.out.println("This is a "+this.furnitureClass);
        System.out.println("Model "+getModel());
        System.out.println("Color "+getColor());
    }

    /**
     * 
     * @param xFurniture furniture for comparison
     * @return returns true if it is equal
    */
    public boolean IsEquals(Furniture xFurniture){
        if(this.model==xFurniture.model&&xFurniture.color==this.color&&xFurniture.furnitureClass.equals(this.furnitureClass))
            return true;
        return false;
    }
}