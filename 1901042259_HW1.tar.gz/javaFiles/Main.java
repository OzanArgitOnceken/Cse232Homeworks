import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        AutomationSystem webSite=new AutomationSystem();
        while(webSite.Menu()){}
        System.out.println("Now try for polymorphsim");
        polymorphism(new Admin());
        polymorphism2(new Admin());
        polymorphism2(new Employee());
    }
    /**
     * it is for test polymorphism
     * @param x takes person class and behaves like admin ,customer or employee
    */
    public static void polymorphism(Person x){
        x.Print();
    }
    /**
     * @param x takes seller interface and behaves like admin or employee
     */
    public static void polymorphism2(Seller x){
        x.printFurnituresWeHave();
    }
}