public class Employee extends Person implements Seller{
    public Furniture branchesFurnitures[];
    private int furnitureIterator;
    private boolean busy;

    /**
     * This is a constructor (Sets branch furniture array's maximum memory to 20)
     */
    public Employee(){
        super("Employee");
        busy=false;
        branchesFurnitures=new Furniture[20];
        furnitureIterator=0;
    }
    /**
     * This method adds furniture to employees memory 
     * @param tempFurniture furniture for add memory
    */
    public void addFurnitureToMemory(Furniture tempFurniture){
        branchesFurnitures[furnitureIterator++]=tempFurniture;
    }
    
    public int getFurnitureIterator() {
        return furnitureIterator;
    }
    
    public void setFurnitureIterator(int furnitureIterator) {
        this.furnitureIterator = furnitureIterator;
    }
    /**
     * Decreases furniture iterator 1
     */
    public void decreaseFurnitureIterator() {
        this.furnitureIterator--;
    }
    
    /**
     * @param orderedFurniture this is furniture for ask is it exists
     * @return method returns true if furniture exists on employees branch
     */
    @Override
    public boolean askFurniture(Furniture orderedFurniture){
        for (int i = 0; i < furnitureIterator; i++) {
            if(orderedFurniture==branchesFurnitures[i]){
                System.out.println("Yes furniture exists");
                return true;}
        }
        System.out.println("Furniture does not exists");
        return false;
    }
    
    /**
     * 
     * @return returns true if employee is busy
    */
    public boolean IsBusy(){
        return this.busy;
    }

    /**
     * This method prints all furnitures on employees Branch
     */
    @Override
    public void printFurnituresWeHave() {
        for (int i = 0; i < furnitureIterator; i++) {
            this.branchesFurnitures[i].printFurniture();
        }
    }

    /**
     * 
     * @param fromCustomer takes furniture order from customer
     * @return if furniture exists returns true
    */
    public boolean sellFurniture(Furniture fromCustomer){
        for (int i = 0; i < furnitureIterator; i++) {
            if(fromCustomer.IsEquals(branchesFurnitures[i])){
                return true;
            }
        }
        return false;
    }

    /**
     * prints customers details and orders
     * @param customerForPrint takes customer for print
    */
    public void printCustomer(Customer customerForPrint){
        customerForPrint.Print();
        customerForPrint.printCustomerOrders();
    }

    /**
     * creates furniture
     * @return returns furniture
     */
    public Furniture addFurniture(){
        return new Furniture();
    }
}