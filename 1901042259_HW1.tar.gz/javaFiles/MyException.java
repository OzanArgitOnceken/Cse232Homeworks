public class MyException extends Exception {
    /**
     * Default constructor
     */
	public MyException(){
        super("Something went wrong");
    }
    /**
     * @param message takes any String for throw an exception
     */
    public MyException(String message){
        super(message);
    }
}