public interface Seller {
    /**
     * employee and Admin both prints furnitures
     * admin asks all branches employee asks only her branch
     */
    public void printFurnituresWeHave();
    /**
     * admin asks all branches employe asks only one branch
     * @param orderedFurniture asking furniture
     * @return returns true if furniture exists 
    */
    public boolean askFurniture(Furniture orderedFurniture);   
}
