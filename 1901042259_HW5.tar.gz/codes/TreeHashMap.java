
public class TreeHashMap<K extends Comparable<K>,V>implements KWHashMap<K, V> {
	private static int maxSize=16;
	private MapObjectTree<K,V>[] mapNodes;
	public TreeHashMap() {
		mapNodes=new MapObjectTree[maxSize];
	}
	/**
	 * this method searches all array sizes and add all of them for calculate the total size of map
	 * 
	 * @return				returns the size of map
	 */
	@Override
	public int size() {
		int size=0;
		for(int i=0;i<maxSize;i++) {
			if(mapNodes[i]!=null)
				size+=mapNodes[i].size();
		}
		return size;
	}

	/**
	 * This method searches the value of key
	 * 
	 * @param key				key for search
	 * @return					returns value of key
	 */
	@Override
	public V get(Object key) {
		if(mapNodes[key.hashCode()%maxSize]==null)
			return null;
		return (V) mapNodes[key.hashCode()%maxSize].get(key);
	}


	/**
	 * This method adds new values with help of MapObjectTree class's put method
	 * 
	 * @param key				key for add
	 * @param value				value for add
	 * @return					if key exists returns old value of the key else returns null
	 */
	@Override
	public V put(K key, V value) {
		
		if(mapNodes[key.hashCode()%maxSize]==null)
			mapNodes[key.hashCode()%maxSize]=new MapObjectTree<K,V>(key,value);
		else {
			return (V) mapNodes[key.hashCode()%maxSize].put(key, value);
		}
		return null;
	}

	/**
	 * This method removes the element from map 
	 * 
	 * @param				key for delete
	 * @return				returns the value of removed key
	 */
	@Override
	public V remove(Object key) {
		if(mapNodes[key.hashCode()%maxSize]==null)
			return null;
		return (V) mapNodes[key.hashCode()%maxSize].remove(key);
	}

	/**
	 * @return				returns string of TreeHashMap
	 */
	@Override
	public String toString() {
		StringBuilder x=new StringBuilder();
		for(int i=0;i<maxSize;i++) {
			x.append(i);
			x.append("->");
			x.append(mapNodes[i]);
			x.append("\n");
		}
		return x.toString();
	}

	/**
	 * @return 				returns true if map is empty
	 */
	@Override
	public boolean isEmpty() {
		return size()==0;
	}
	
}