import java.util.HashMap;
import java.util.Iterator;
/**
 * This is my iterator class
 * @author Ozan Argit Onceken
 */
public class IteratorMap<K, V> extends HashMap<K, V> {
    
    private class MapIterator<K> implements IteratorInterface<K> {
    	private Iterator<K> iter;
    	private int current;
    	/**
    	 * default constructor
    	 */
    	public MapIterator()
    	{
    		iter = (Iterator<K>) keySet().iterator();
    		current = 0;
    	}
    	/**
    	 * constructor from start at stated
    	 */
        public MapIterator(K key)
        {
        	current = 0;
        	while (iter.hasNext())
        		if (iter.next().equals(key)) 
        			return;
        }
        /**
         * goes next
         * @return 					returns key of current node
         */
        public K next()
        {	
        	current++;
            return (K) iter.next();
        }
        /**
         * goes previous
         * @return 					returns key of current node
         */
        public K prev()
        {
        	
            iter = (Iterator<K>) keySet().iterator();
            for (int i = 0; i < current- 1; ++i)
            	iter.next();
            --current;
            return (K) iter.next();
            
        }
        /**
         * @return 					returns true if has next
         */
        public boolean hasNext()
        {
            return iter.hasNext();
        }
    }

    /**
     * @return						returns iterator for map
     */
    public IteratorInterface<K> iterator()
    {
        return new MapIterator<K>();
    }
}
