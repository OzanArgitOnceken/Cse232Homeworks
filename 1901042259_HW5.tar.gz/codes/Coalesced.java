import java.util.ArrayList;
/**
 * This class have an array and every index of array contains a Node object 
 * Every method derived from KWHashMap
 * @author Ozan Argit Onceken
 */
public class Coalesced <K extends Comparable<K>,V>implements KWHashMap{
	private Node<K,V> []array;
	private int size;
	private int maxSize;

	/**
	 * Constructor of Coalesced class
	 */
	public Coalesced() {
		this.maxSize=10;
		array=new Node[this.maxSize];
		size=0;
	}
	
	/**
	 * This is class have key value and next variables.
	 * next holds the place of next element(if next element's hash code is same with current)
	 * if there are no next element next element holds -1
	 * key holds key and value holds value
	 * @author Ozan Argit Onceken
	 */
	private static class Node<K extends Comparable<K>,V> implements Comparable<K>{
		K key;
		V value;
		int next;
		boolean empty;
		/**
		 * Constructor of Node
		 */
		@SuppressWarnings("unused")
		protected Node() {
			this.key=null;
			this.value=null;
			this.next=-1;
			this.empty=true;
		}
		/**
		 * Constructor of Node
		 * next=-1
		 * @param newKey				for set key 
		 * @param newValue				for set new Value
		 */
		protected Node(K newKey,V newValue) {
			this.key=newKey;
			this.value=newValue;
			this.next=-1;
			this.empty=false;
		}
		/**
		 * @return 					returns next
		 */
		protected int getNext() {
			return this.next;
		}
		/**
		 * @param next				next for set
		 */
		protected void setNext(int next) {
			this.next=next;
		}
		/**
		 * @return					returns key
		 */
		protected K getKey() {
			return key;
		}
		/**
		 * @return 					returns value
		 */
		protected V getValue() {
			return value;
		}
		
		/**
		 *@param value				sets value
		 */
		@SuppressWarnings("unused")
		protected void setValue(V value) {
			this.value = value;
		}
		/**
		 * @return					returns true if node is created but not holds anything
		 */
		protected boolean isEmpty() {
			return empty;
		}
		/**
		 * @return					returns string of node
		 */
		public String toString() {
			return "("+key.toString()+"=>"+value.toString()+")"+"->"+next;
		}
		/**
		 * compares the keys of nodes
		 */
		@Override
		public int compareTo(K o) {
			return this.key.compareTo(o);
		}
	}

	/**
	 * This method searches the value of key
	 * 
	 * @param key				key for search
	 * @return					returns value of key
	 */
	@Override
	public V get(Object key) {
		int lookPlace=key.hashCode()%maxSize;
		if(array[lookPlace].getKey().compareTo((K)key)==0)
			return array[lookPlace].getValue();
		else {
			if(array[lookPlace].getNext()>0) {
				while(array[lookPlace].getNext()>0) {
					lookPlace=array[lookPlace].getNext();
					if(array[lookPlace].getKey().compareTo((K)key)==0)
						return array[lookPlace].getValue();
				}
			}
		}
		return null;
	}


	/**
	 * @return 				returns true if map is empty
	 */
	@Override
	public boolean isEmpty() {
		return size==0;
	}


	/**
	 * 
	 * 
	 * @param key				key for add
	 * @param value				value for add
	 * @return					if key exists returns old value of the key else returns null
	 */
	@Override
	public Object put(Object key, Object value){
		if(size==maxSize) {
			rehash();
		}
		int putPlace=key.hashCode()%maxSize;
		if(array[putPlace]==null||array[putPlace].isEmpty()) {
			array[putPlace]=new Node((K)key,(V)value);
			size++;
		}
		else {
			if(array[putPlace].getKey().compareTo((K)key)==0)
				array[putPlace].setValue((V)value);
			else {
				if(size!=maxSize) {
					int i=0;
					int firstPlace=putPlace;
					while(true) {
						i++;
						
						if(array[putPlace].getKey().compareTo((K)key)==0) {
							V val=array[putPlace].getValue();
							array[putPlace].setValue((V)value);
							return val;
						}
						if(array[putPlace].getNext()!=-1&&(array[putPlace].getKey().hashCode()%maxSize)==key.hashCode()%maxSize) {
							putPlace=array[putPlace].getNext();
							firstPlace=putPlace;
						}
						else {
							putPlace=(key.hashCode()+i*i)%maxSize;
						}
						if(array[putPlace]==null||array[putPlace].isEmpty()) {
							array[putPlace]=new Node((K)key,(V)value);
							array[firstPlace].setNext(putPlace);
							size++;
							break;
						}
					}
				}
			}
		}
		return null;
	}

	/**
	 * This is a helper method that finds the index of key and returns it for remove method
	 * and remove make the operation about it
	 * 
	 * @param key 			key for search
	 * @return				returns the index of key
	 */
	private int find(Object key) {
        int index = key.hashCode() %maxSize;
        if(array[index]==null)
        	return -1;
        while(array[index].getNext()!=-1) {
        	if(array[index].getKey().equals(key))
        		return index;
        	index=array[index].getNext();
        }
    	if(array[index].getKey().equals(key))
    		return index;
        return -1;
    }
	/**
	 * it is a helper function 
	 * If remove method deletes the last element the element before last does not removes its
	 * next so this method helps for find element before the last and makes its next -1
	 * later remove method deletes the last.
	 * 
	 * @param key			key for search
	 * @return				returns the index of one before last element
	 */
	private int findNext(Object key){
        int index = key.hashCode() %maxSize;
        if(array[index]==null)
        	return -1;
        while(array[array[index].getNext()].getNext()!=-1) {
        	if(array[index].getKey().equals(key))
        		return index;
        	index=array[index].getNext();
        }
    	if(array[array[index].getNext()].getKey().equals(key))
    		return index;
		return -1;
	}
	
	
	
	/**
	 * This method removes the element from map 
	 * It removes element ,rearrange the map correctly and arranges the next of the nodes
	 * 
	 * @param				key for delete
	 * @return				returns the value of removed key
	 */
	@Override
	public Object remove(Object key) {
		int indexFirst=find(key);
		if(indexFirst==-1)
			return null;
		int index=indexFirst;
		if(array[index].getNext()==-1) {
			int temporary=findNext(key);
			array[temporary].setNext(-1);
		}
		ArrayList <Integer>temp=new ArrayList<Integer>();
		while(array[index].getNext()!=-1) {
			int next=array[index].getNext();
			temp.add(array[index].getNext());
			next=array[index].getNext();
			array[index]=array[array[index].getNext()];
			index=next;
		}
		V val=array[index].getValue();
		array[index]=null;
		for(int i=0;i<temp.size()-1;i++) {
			array[indexFirst].setNext(temp.get(i));
			indexFirst=array[indexFirst].getNext();
		}
		size--;
		return val;
		
	}

	
	/**
	 * @return 				returns the size
	 */
	@Override
	public int size() {
		return size;	
	}
	private void rehash() 
    {
        // Save a reference to oldTable.
        Node<K, V>[] oldTable = array;
        // Double capacity of this table.
        array= new Node[2 * oldTable.length + 1];
        maxSize=2 * oldTable.length + 1;
        // Reinsert all items in oldTable into expanded table.
        size = 0;
        for (int i = 0; i < oldTable.length; i++) {
            if ((oldTable[i] != null)) {
                // Insert entry in expanded table
                put(oldTable[i].getKey(), oldTable[i].getValue());
            }
     }
    }
	/**
	 * @return				returns string of Coalesced
	 */
	public String toString() {
		StringBuilder x=new StringBuilder();
		for(int i=0;i<maxSize;i++) {
			if(array[i]!=null) {

				x.append(i);
				x.append("->");
				x.append(array[i].getKey());
				x.append("=>");
				x.append(array[i].getValue());
				if(array[i].getNext()>0) {
					x.append("==>");
					x.append(array[i].getNext());
				}
				x.append("\n");
			}
			else {
				x.append(i);
				x.append("->");
				x.append("Empty");
				x.append("\n");
			}
		}
		return x.toString();
	}
}