import java.util.Iterator;
import java.util.TreeSet;

/**
 * This class is for hold the keys and holds a treeSet
 * This class holds the size of tree
 * @author Ozan Argit Onceken
 */
public class MapObjectTree<K extends Comparable<K>, V>{
	private TreeSet<Node> tree;
	private Node<K,V> last;
	private int size;
	/**
	 * default constructor
	 */
	public MapObjectTree() {
		this.size=0;
		tree=new TreeSet<Node>();
	}
	/**
	 * @param key				key for set
	 * @param value				value for set
	 */
	public MapObjectTree(K key,V value) {
		tree=new TreeSet<Node>();
		last=new Node(key,value);
		tree.add(last);
		size=1;
	}
	/**
	 * @return 					returns true if size=0
	 */
	public boolean isEmpty() {
		return this.size()==0;
	}
	/**
	 * @param key				key for set
	 * @param					value for set
	 * @return					returns value if key existed before
	 */
	public V put(K key, V value) {
		Iterator<Node>iter=tree.iterator();
		while(iter.hasNext()) {
			Node <K,V>temp=iter.next();
			if(temp.getKey().compareTo(key)==0) {
				V tempVal=temp.getValue();
				temp.setValue(value);
				return tempVal;
			}
		}
		tree.add(new Node(key,value));
		size++;
		return null;
	}
	/**
	 * @param key 					key for get
	 * @return						returns the value of key if key does not exists returns null
	 */
	public V get(Object key) {
		Iterator<Node>iter=tree.iterator();
		while(iter.hasNext()) {
			Node<K,V> temp=iter.next();
			if(temp.getKey().compareTo((K) key)==0)
				return temp.getValue();
		}
		return null;
	}
	/**
	 * @param key					key for remove
	 * @return						returns the old value
	 */
	public V remove(Object key) {
		int i=0;
		Iterator<Node>iter=tree.iterator();
		while(iter.hasNext()) {
			i++;
			Node<K,V> temp=iter.next();
			if(temp.getKey().compareTo((K) key)==0) {
				int j=0;
				Iterator<Node>iterForRemove=tree.iterator();
				while(j<i) {
					j++;
					iterForRemove.next();
				}
				iterForRemove.remove();
				size--;
				return temp.getValue();
			}
		}
		return null;
	}
	/**
	 * @return						returns size
	 */
	public int size() {
		return size;
	}
	/**
	 * @return 						return string for toString method
	 */	
	public String toString() {
		return tree.toString();
	}
	
}