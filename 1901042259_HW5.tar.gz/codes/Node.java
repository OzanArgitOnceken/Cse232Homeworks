/**
 * This class is actually inner class of LinkedHashMap and
 */
public class Node<K extends Comparable<K>,V> implements Comparable<K>{
	private K key;
	private V value;
	/**
	 * default constructor
	 */
	@SuppressWarnings("unused")
	public Node() {
		key=null;
		value=null;
	}
	/**
	 * @param newKey 				newKey for set key
	 * @param newValue				newValue for set value
	 */
	public Node(K newKey,V newValue) {
		this.key=newKey;
		this.value=newValue;
	}
	/**
	 * @return						returns key
	 */
	public K getKey() {
		return key;
	}
	/**
	 * @return						returns value
	 */
	public V getValue() {
		return value;
	}
	/**
	 * @param value 				sets value
	 */
	@SuppressWarnings("unused")
	public void setValue(V value) {
		this.value = value;
	}
	/**
	 * @return						returns toString method
	 */
	public String toString() {
		return "("+key.toString()+"=>"+value.toString()+")";
	}
	/**
	 * compares the keys of nodes
	 * @param o 					other node
	 */
	@Override
	public int compareTo(K o) {
		return o.compareTo(this.key);
	}
}