import java.util.Iterator;
/**
 * this class is for add my iterator to prev method
 * @author Ozan Argit Onceken
 */
public interface IteratorInterface<K> extends Iterator<K> {
	public K prev();
}
