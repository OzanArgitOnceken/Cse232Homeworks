public class Main {
	public static void main(String args[]) {
			
		IteratorMap<Integer, String> map = new IteratorMap<Integer, String>();
	
		System.out.println("\t\t\t .:Part 1:.\n");
		System.out.println("Adding some random <Integer,String> values to the map");
		map.put(14, "Gebze "); // 12
		map.put(435, "Technical "); // 9
		map.put(2, "University "); // 10
		map.put(436, "Computer "); // 14
		map.put(44, "Engineering ");
		System.out.println("Map:"+map);
		
		System.out.println("Writing the same map with iterator(using next and hasNext method)");
		IteratorInterface iter = map.iterator();
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
		
		System.out.println("Now writing with previous method");
		System.out.println(iter.prev());
		System.out.println(iter.prev());
		System.out.println(iter.prev());
		System.out.println(iter.prev());
		System.out.println(iter.prev());
		System.out.println();
		
		
		
		
		
		
		
		System.out.println("\t\t\t.:PART 2:.\n");
		System.out.println("\t a)Chaining Technique with Linked List:");
		System.out.println("Now creating a chain hash map(hash map includes linkedList)");
		LinkedHashMap<Integer,Integer>linkedMap=new LinkedHashMap<Integer,Integer>();
		System.out.println("Is linkedMap empty="+linkedMap.isEmpty());
		System.out.println("Adding some values(<Integer,Integer>)(map size=16)");
		System.out.println("Before => symbol integer represents the key");
		System.out.println("After => symbol integer represents the value");
		linkedMap.put(12, 1);
		linkedMap.put(1, 32);
		linkedMap.put(122, 354);
		linkedMap.put(1224, 456);
		linkedMap.put(16,8);
		linkedMap.put(32, 9);
		linkedMap.put(322, 9);
		linkedMap.put(3242, 9);
		linkedMap.put(16, 4);
		linkedMap.put(64, 0);
		linkedMap.put(96, 98);
		System.out.println(linkedMap);
		
		System.out.println("Now putting 12=>2 and it will change the value of hash");
		System.out.println("For see in linkedList's value change putting 16=>1,32=>2,64=>3,96=>4");
		System.out.println("After that adding non existed value:100=>3");
		System.out.println("12's value was "+linkedMap.put(12, 2)+" before changed");
		System.out.println("16's value was "+linkedMap.put(16, 1)+" before changed");
		System.out.println("32's value was "+linkedMap.put(32, 2)+" before changed");
		System.out.println("64's value was "+linkedMap.put(64, 3)+" before changed");
		System.out.println("96's value was "+linkedMap.put(96, 4)+" before changed");
		System.out.println("100's value was "+linkedMap.put(100, 3)+" because it was not existed before");
		System.out.println(linkedMap);
		System.out.println("Removing not existed key(97)");
		System.out.println("Value of removing 97 is "+linkedMap.remove(97)+" because it was not existed");
		System.out.println("Value of removing 100 is "+linkedMap.remove(100)+" because it was not existed");
		System.out.println("Value of removing 64 is "+linkedMap.remove(64)+" because it was not existed");
		System.out.println("Value of removing 100 is "+linkedMap.remove(16)+" because it was not existed");
		System.out.println(linkedMap);
		System.out.println("Adding after remove(1001=>1)");
		linkedMap.put(1001, 1);
		System.out.println(linkedMap);
		System.out.println("Getting nonexisted value(97) is "+linkedMap.get(97));
		System.out.println("Getting existed value(12) is "+linkedMap.get(12));
		System.out.println("Getting existed value(96) is "+linkedMap.get(96));
		System.out.println("Size of linkedMap="+linkedMap.size());
		System.out.println("Is linkedMap empty="+linkedMap.isEmpty());
		
		
		
		
		
		System.out.println("\n\n\n\t b)Chaining Technique with TreeSet:");
		TreeHashMap<Integer,Integer> treeMap=new TreeHashMap<Integer,Integer>();
		System.out.println("Is treeSet empty: "+treeMap.isEmpty());
		System.out.println("Adding some values (<Integer,Integer>)to treeMap:");
		System.out.println("Size of treeMap is 16 so hashcode dividing with 16.");
		treeMap.put(13, 5);
		treeMap.put(4,  4);
		treeMap.put(2, 14);
		treeMap.put(1, 58);
		treeMap.put(17, 21);
		treeMap.put(33, 34);
		treeMap.put(24, 76);
		treeMap.put(90, 0);
		treeMap.put(21, 12);
		treeMap.put(54, 56);
		treeMap.put(10, 23);
		treeMap.put(32, 78);
		treeMap.put(48, 1);
		treeMap.put(64, 99);
		System.out.println(treeMap);
		System.out.println("Now adding the same element");
		System.out.println("Value of 64 was "+treeMap.put(64, 4)+" before setting it to 4");
		System.out.println("Value of 24 was "+treeMap.put(24, 123)+" before setting it to 123");
		System.out.println("New treeMap:");
		System.out.println(treeMap);
		System.out.println("Removing not existed element(111) returns "+treeMap.remove(111));
		System.out.println("Removing 48 returns "+treeMap.remove(48));
		System.out.println("Removing 21 returns "+treeMap.remove(21));
		System.out.println("Adding after remove(1001=>1)");
		treeMap.put(1001, 1);
		System.out.println(treeMap);
		System.out.println("Getting nonexisted key(444) returns "+treeMap.get(444));
		System.out.println("Getting existed key(64) returns "+treeMap.get(64));
		System.out.println("Size of treeMap:"+treeMap.size());
		System.out.println("Is treeSet empty: "+treeMap.isEmpty());
		
		
		
		
		
		
		
		System.out.println("\n\n\n\t c) Coalesced hashing Technique :");
		Coalesced<Integer,Integer>coalesced=new Coalesced<Integer,Integer>();
		System.out.println("Size of coalesced:"+coalesced.size());
		System.out.println("Coalesced is empty="+coalesced.isEmpty());

		System.out.println("Adding values(<Integer,Integer>) to coalesced in try catch because if user use puts more than");
		System.out.println("10 put method should throws an error");
		coalesced.put(3, 1);
		coalesced.put(13, 2);
		coalesced.put(23, 4);
		coalesced.put(33, 5);
		coalesced.put(323, 312);
		coalesced.put(3133, 312);
		coalesced.put(45131, 312);
		coalesced.put(451311, 312);
		coalesced.put(1, 312);
		coalesced.put(11, 312);
		System.out.println(coalesced);
		System.out.println("Removing 1: "+coalesced.remove(1));
		System.out.println(coalesced);
		System.out.println("Removing 13: "+coalesced.remove(13));
		System.out.println(coalesced);
		System.out.println("Adding 93 after remove: ");
		coalesced.put(93, 11);
		System.out.println(coalesced);
		System.out.println("Value of 93:"+coalesced.get(93));
		System.out.println("Value of nonexisted value(1000000):"+coalesced.get(1000000));
		System.out.println("Changing the value of 93 to 3545");
		coalesced.put(93, 3545);
		System.out.println(coalesced);
		System.out.println("Adding extra for rehash");
		coalesced.put(932, 3545);
		coalesced.put(9334, 3545);
		coalesced.put(93123, 3545);
		coalesced.put(931233, 3545);
		System.out.println(coalesced);

		System.out.println("Size of coalesced:"+coalesced.size());
		System.out.println("Coalesced is empty="+coalesced.isEmpty());
		
	}

}
