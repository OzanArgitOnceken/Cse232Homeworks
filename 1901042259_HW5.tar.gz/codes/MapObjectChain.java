import java.util.LinkedList;
import java.util.ListIterator;


/**
 * This class is for hold the keys and holds a LinkedList
 * This class holds the size of tree
 * @author Ozan Argit Onceken
 */
public class MapObjectChain<K extends Comparable<K>, V> {
	
	private LinkedList<Node>list;
	private Node last;
	private int size;
	/**
	 * @param key				key for set
	 * @param value				value for set
	 */
	public MapObjectChain(K key,V value) {
		list=new LinkedList<Node>();
		last=new Node<K,V>(key,value);
		list.add(last);
		size=1;
	}
	/**
	 * default constructor
	 */
	public MapObjectChain() {
		list=new LinkedList<Node>();
		size=0;
	}
	
	

	/**
	 * @param key				key for set
	 * @param					value for set
	 * @return					returns value if key existed before
	 */
	
	public V put(K newKey,V newValue) {
		ListIterator<Node> tempIter = list.listIterator();
        while(tempIter.hasNext()) {
        	if(tempIter.next().getKey().equals(newKey)){
        		Node <K,V>temp;
        		tempIter.previous();
        		temp=tempIter.next();;
        		tempIter.previous();
        		tempIter.set(new Node(newKey,newValue));
        		return (V) temp.getValue();
        	}
        }
    	tempIter.add(new Node(newKey,newValue));
    	size++;
    	return null;
	}
	
	/**
	 * @param key					key for remove
	 * @return						returns the old value
	 */
	public V remove(Object key) {
		V val;
		ListIterator<Node>iter=list.listIterator();
		while(iter.hasNext()) {
			if(iter.next().getKey()==key) {
				iter.previous();
				val=(V) iter.next().getValue();
				iter.previous();
				iter.remove();
				size--;
				return val;
			}
		}
		return null;
	}
	/**
	 * @return			returns size
	 */
	public int size() {
		return size;
	}
	/**
	 * @return 					returns true if size=0
	 */
	public boolean isEmpty() {
		return this.size()==0;
	}

	/**
	 * @param key 					key for get
	 * @return						returns the value of key if key does not exists returns null
	 */
	public V get(Object key) {
		ListIterator<Node>iter=list.listIterator();
		while(iter.hasNext()) {
			if(iter.next().getKey()==key) {
				iter.previous();
				return (V) iter.next().getValue();
			}
		}
		return null;
	}
	/**
	 * @return 						return string for toString method
	 */
	public String toString() {
			return list.toString();
	}
}
