
public interface KWHashMap <K,V>{

	/**
	 * This method searches the value of key
	 * 
	 * @param key				key for search
	 * @return					returns value of key
	 */
	public V get(Object key);
	/**
	 * @return 				returns true if map is empty
	 */
	public boolean isEmpty();
	/**
	 * This method adds new values with help of other class's put method
	 * 
	 * @param key				key for add
	 * @param value				value for add
	 * @return					if key exists returns old value of the key else returns null
	 */
	public V put(K key, V value) throws Exception;
	/**
	 * This method removes the element from map 
	 * 
	 * @param				key for delete
	 * @return				returns the value of removed key
	 */
	public V remove(Object key);
	/**
	 * @return				returns size of map
	 */
	public int size();
}
