public class Employee extends Person implements Seller{
    public MyHybridList<Furniture> branchesFurnitures;
    private int furnitureIterator;
    private boolean busy;

    /**
     * This is a constructor (Sets branch furniture array's maximum memory to 20)
     */
    public Employee(){
        super("Employee");
        busy=false;
        branchesFurnitures=new MyHybridList<Furniture>();
        furnitureIterator=0;
    }
    public Employee(boolean x){
        super("Employee",true);
        busy=false;
        branchesFurnitures=new MyHybridList<Furniture>();
        furnitureIterator=0;
    }
    /**
     * This method adds furniture to employees memory 
     * @param tempFurniture furniture for add memory
    */
    public void addFurnitureToMemory(Furniture tempFurniture){
        branchesFurnitures.add(tempFurniture);
        furnitureIterator++;
    }
    
    public int getFurnitureIterator() {
        return furnitureIterator;
    }
    
    public void setFurnitureIterator(int furnitureIterator) {
        this.furnitureIterator = furnitureIterator;
    }
    /**
     * Decreases furniture iterator 1
     */
    public void decreaseFurnitureIterator() {
        this.furnitureIterator--;
    }
    
    /**
     * @param orderedFurniture this is furniture for ask is it exists
     * @return method returns true if furniture exists on employees branch
     */
    @Override
    public boolean askFurniture(Furniture orderedFurniture){
        for (int i = 0; i < furnitureIterator; i++) {
            if(branchesFurnitures.contains(orderedFurniture)){//O(n)
                System.out.println("Yes furniture exists");
                return true;}
        }
        System.out.println("Furniture does not exists");
        return false;
    }
    
    /**
     * 
     * @return returns true if employee is busy
    */
    public boolean IsBusy(){
        return this.busy;
    }

    /**
     * This method prints all furnitures on employees Branch
     */
    @Override
    public void printFurnituresWeHave() {
    	System.out.println(branchesFurnitures);
    }

    /**
     * 
     * @param fromCustomer takes furniture order from customer
     * @return if furniture exists returns true
    */
    public boolean sellFurniture(Furniture fromCustomer){//Omn
        for (int i = 0; i < furnitureIterator; i++) {
            if(fromCustomer.equals(branchesFurnitures.get(i))){
                return true;
            }
        }
        return false;
    }

    /**
     * prints customers details and orders
     * @param customerForPrint takes customer for print
    */
    public void printCustomer(Customer customerForPrint){
        customerForPrint.Print();
        customerForPrint.printCustomerOrders();
    }

    /**
     * creates furniture
     * @return returns furniture
     */
    public Furniture addFurniture(){
        return new Furniture();
    }
    public String toString() {
    	StringBuilder result = new StringBuilder();
    	result.append("Welcome to Employee ");
    	result.append(getName()+" empemp.\n We have:"+branchesFurnitures.toString()+"\n");
        return result.toString();
    }
}