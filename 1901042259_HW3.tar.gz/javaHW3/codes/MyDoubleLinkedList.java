
import java.util.Iterator;
import java.util.ListIterator;

public class MyDoubleLinkedList<E> {
	private Node<E> headNode;
	private Node<E> lastNode;
	private int size;
	/**
	 * sets head and last node to null
	 */
	public MyDoubleLinkedList() {
		size=0;
		this.headNode=null;
		this.lastNode=null;
	}
	/**
	 * @param data for add
	 */
	public void add(E data) {
		if(headNode==null) {
			addToHead(data);
			lastNode=headNode;
		}
		else
		{
			lastNode.next=new Node(data,lastNode);
			lastNode=lastNode.next;
		}
		size++;
	}
	/**
	 * @param for create first note
	 */
	private void addToHead(E data) {
		this.headNode=new Node(data);
	}
	/**
	 * Node class holds data and next and previous nodes
	 */
	private class Node<E>{
		E data;
		Node<E>next;
		Node<E>prev;
		/**
		 * @param data sets data
		 * sets next and previous to null
		 */
		public Node(E data) {
			this.data=data;
			this.next=null;
			this.prev=null;
		}
		/**
		 * @param data sets data
		 * @param prev sets previous node to prev
		 * sets next node to null
		 */
		public Node(E data,Node<E>prev) {
			this.data=data;
			this.next=null;
			this.prev=prev;
		}
		/**
		 * @param data sets data
		 * @param prev sets previous node to prev
		 * @param next sets next node to next
		 */
		public Node(E data,Node<E>prev,Node<E>next) {
			this.data=data;
			this.prev=prev;
			this.next=next;
		}
	}

	public String toString() {//O(n)
        Node<E> nodeRef = headNode;
        StringBuilder result = new StringBuilder();
        while (nodeRef != null) {
            result.append(nodeRef.data);
            if (nodeRef.next != null)
                result.append(" ==> ");
            nodeRef = nodeRef.next;
        }
        return result.toString();
	}
	/**
	 * @return returns String that list written form last to first
	 */
	public String printBackward() {
        Node<E> nodeRef = lastNode;
        StringBuilder result = new StringBuilder();
        while (nodeRef != null) {
            result.append(nodeRef.data);
            if (nodeRef.prev!= null) {
                result.append(" ==> ");
            }
            nodeRef = nodeRef.prev;
        }
        return result.toString();
	}
	
	/**
	 * @param adds data to head
	 */
	public void addAtBeggining(E data) {
		if(headNode!=null) {
			headNode=new Node<E>(data,null,headNode);
			size++;
		}
		else 
			headNode=new Node<E>(data);
	}
	/**
	 * @param index index where wanted to add
	 * @param data for addd
	 */
	public void addToIndex(int index,E data)
	{
		try {
			if(index<0||index>=size)
				throw new Exception("Wrong index :(");
			else {
				Node<E>temp;
				if(size-index<index) {
					temp=lastNode;
					for(int i=size;i>index;--i)
					{
						temp=temp.prev;
					}
					Node<E> tempTemp=temp.next;
					temp.next=new Node<E>(data,temp,tempTemp);
					tempTemp.prev=temp.next;
				}
				else
				{
					temp=headNode;
					for(int i=0;i<index;i++) {
						temp=temp.next;
					}
					Node<E>tempTemp=temp.next;
					temp.next=new Node<E>(data,temp,tempTemp);
					tempTemp.prev=temp.next;
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	/**
	 * @return returns true if it does not throws exception
	 * @param index index data wanted to remove
	 */
	public boolean Remove(int index) {
		try {
			if(index<0||index>size)
				throw new Exception("Wrong index");
			else {
				if(index==size) {
					if(lastNode!=headNode) {
						lastNode=lastNode.prev;
						lastNode.next=null;
					}
					else {
						headNode=null;
						lastNode=null;
					}
				}
				else if(index==0) {
					if(headNode.next!=null)
						headNode=headNode.next;
					else
						headNode=null;
				}
				else {
					Node<E>temp=headNode;
					for(int i=0;i<index-1;++i)
					{
						temp=temp.next;
					}
					temp.next=temp.next.next;
					temp.next.prev=temp;
				}
				size--;
				return true;
			}
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return false;
	}
	
	/**
	 * @return returns the data
	 * @param wanted index
	 */
	public E get(int index) {
		int i=0;
		if(headNode==null)
			return null;
		Node temp=headNode;
		if(index<size) {
			while(i<index){
				temp=temp.next;
				++i;
			}
		}
		return (E) temp.data;
	}
	public boolean Contains(E data) {
		return false;
	}
	public int size() {
		return this.size;
	}
	/**
	 * @return creates and returns iterator
	 */
	public Iterator <E> MyIterator(){
		return new MyIterator();
	}
	
	private class MyIterator implements ListIterator<E>{
		private Node<E> nextItem;
		private Node<E> lastItemReturned;
		private int index;
		/**
		 * creates iterator
		 */
		public MyIterator() {
			this.index=0;
			nextItem=headNode;
			lastItemReturned=null;
		}
		/**
		 * @return returns true if next node exists
		 */
		@Override
		public boolean hasNext() {
			return index<size;
		}

		/**
		 * @return returns data
		 * and goes next
		 */
		@Override
		public E next() {
			
			if(hasNext()) {
				lastItemReturned=nextItem;
				nextItem=nextItem.next;
			}
			index++;
			return lastItemReturned.data;
		}

		/**
		 * @return returns true if previous node exists
		 */
		@Override
		public boolean hasPrevious() {
			return index>0;
		}

		/**
		 * @return returns data
		 * and goes previous
		 */
		@Override
		public E previous() {
			if(hasPrevious())
			{
				lastItemReturned=nextItem;
				nextItem=nextItem.prev;
			}
			return lastItemReturned.data;
		}

		/**
		 * @return returns next index
		 */
		@Override
		public int nextIndex() {
			return index+1;
		}

		/**
		 * @return returns previous index
		 */
		@Override
		public int previousIndex() {
			return index+1;
		}

		/**
		 * removes next node
		 */
		@Override
		public void remove() {
			nextItem.next=nextItem.next.next;
			nextItem.next.next.prev=nextItem.prev;
			nextItem=nextItem.next;
			index--;
			size--;
		}

		/**
		 * @param data for change with current item
		 */
		@Override
		public void set(E e) {
			nextItem.data=e;
		}

		/**
		 * @param data for next item
		 * creates a node between this and next node
		 */
		@Override
		public void add(E e) {
			nextItem.next=new Node(e,nextItem,nextItem.next);
			
		}
		
	}
	/**
	 * @return returns last node
	 */
	public Node<E> getLast(){
		return lastNode;
	}
	/**
	 * @param data removes node includes data from list
	 */
	public void remove(Furniture data) {
		Node temp=headNode;
		while(temp!=null) {
			if(temp.data==data) {
				if(temp.next==null){
					lastNode=temp.prev;
					lastNode.next=null;
				}
				else if(temp.prev==null) {
					headNode=headNode.next;
					headNode.prev=null;
				}
				else if(lastNode==headNode) {
					headNode=null;
					lastNode=null;
				}
				else {
					temp.prev.next=temp.next;
					temp.next.prev=temp.prev;
				}
				size--;
				break;
			}
			temp=temp.next;
		}
	}
}
