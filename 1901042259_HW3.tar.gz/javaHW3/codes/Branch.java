import java.util.Scanner;

public class Branch {
    private String name;
    private MyHybridList<Furniture> branchFurnitures;
    private MyDoubleLinkedList<Employee> branchEmployees;
    private int furniture_iterator;
    private int employeeIterator;
    /**
     * This constructor takes branch name as input and sets furniture and employee 
     * arrays max memory to 20
     */
    public Branch(){
        branchFurnitures=new MyHybridList();
        setFurnitureAmount(0);
        Scanner inputScanner=new Scanner(System.in);
        setBranchName(inputScanner.nextLine());
        branchEmployees=new MyDoubleLinkedList<Employee>();
        employeeIterator=0;
    }
    /**
     * it is a constructor
     *@param name name of branch(string)
     */
    public Branch(String name){
        branchFurnitures=new MyHybridList<Furniture>();
        setFurnitureAmount(0);
        setBranchName(name);
        branchEmployees=new MyDoubleLinkedList<Employee>();
        employeeIterator=0;
    }
    /**
     * Constructor
     * @param namename of branch(string)
     * @param max_furniture_amount maximum furniture amount for memory allocation
     * @param maxEmployee maximum employee amount for memory allocation
    */
    public Branch(String name,int max_furniture_amount,int maxEmployee){
        this.branchFurnitures=new MyHybridList();//my array is dynamic so I did not change anything
        setFurnitureAmount(0);
        setBranchName(name);
        branchEmployees=new MyDoubleLinkedList<Employee>();
        employeeIterator=0;
    }

    /**
     * This method adds employee on branch
     * @param temp Employee for add branch
     */
    public void addEmployee(Employee temp){//on^2
        branchEmployees.add(temp);
        employeeIterator++;
        for (int i = 0; i < furniture_iterator; i++)//on^2
        	temp.addFurnitureToMemory(branchFurnitures.get(i));
    }
    
    /**
     * This method adds any furniture on branch
     * @param tempFurniture furniture for adding branch
    */
    public void addFurniture(Furniture tempFurniture){
    	branchFurnitures.add(tempFurniture);
        for (int i = 0; i < employeeIterator; i++)//O(n^2)
            branchEmployees.get(i).addFurnitureToMemory(tempFurniture);
        furniture_iterator++;
    }

    protected void setBranchName(String name){
        this.name=name;
    }

    protected void setFurnitureAmount(int number){
        this.furniture_iterator=number;
    }

    public String getName(){
        return name;
    }

    public int getFurnitureAmounts() {
        return furniture_iterator;
    }

    /**
     * This method prints all details about branch (furnitures on branch and employees on branch)
     */
    public void printBranch(){
        System.out.println("Welcome to "+getName()+" branch.\n We have:");
        System.out.println(branchFurnitures);
        printBranchEmployees();
    }

    /**
     * Prints all furnitures on branch
     */
    public void printFurniture(){
        if(getFurnitureAmounts()==0)
            System.out.println("No furnitures");
        System.out.println(branchFurnitures);
    }

    /**
     * prints all employees on branch
     */
    public void printBranchEmployees(){
    	System.out.println(branchEmployees);
    }
    
    public int getEmployeeIterator(){
        return employeeIterator;
    }


    /**
     * @param temp searching furniture object
     * @return if this branch have the temp furniture returns true
     * 
     */
    public boolean haveFurniture(Furniture temp)//O(mn)
    { 
    	for (int i = 0; i < furniture_iterator; i++) {
        if(branchFurnitures.contains(temp)) {
        	System.out.println("Branch "+getName()+" Have furniture.");
            return true;
        	}
    	}
    	return false;
    }
    /**
     * this method sells a furniture (deletes furniture from branch and all employees)
     * if furniture can not found it throws an exception
     * @param ordered this is ordered furniture
     * @return returns true if sale happens
    */
    public boolean sellFurniture(Furniture ordered){
        try {
            boolean founded=false;
            for (int i = 0; i <furniture_iterator; i++) {
            	
                if(branchFurnitures.equals(ordered)){
                    founded=true;
                    branchFurnitures.remove(i);;
                    furniture_iterator--;
                    for (int j = 0; j < employeeIterator; j++) {
                    	branchEmployees.remove(ordered);
                    }
                    break;
                }
            }
            if(founded==true)
                throw new MyException("There are no furnitures like you have searched");
                else
                    return true;
        } catch (Exception e) {
                System.out.println(e.getMessage());
                return false;
        }
    }
    /**
     * when some furniture added or deleted from branch this method resets an 
     * employee memory
     * @param worker sended worker for reset memorised products
    */
    
    
    /*
     
    public void resetEmployeeProducts(Employee worker){
        for (int i = 0; i <=furniture_iterator; i++){
            worker.branchesFurnitures()=branchFurnitures.get(i);
        }
        worker.decreaseFurnitureIterator();
    }
     */

    /**
     * @param tempEmployee takes employee for search
     * @return returns true if employee works on branch
    */
    public boolean isEmployeeWorksHere(Employee tempEmployee){//kmn
        for (int i = 0; i < employeeIterator; i++) {//n
            if(tempEmployee.getName().equals(branchEmployees.get(i).getName()))//km
                return true;
        }
        return false;
    }
    /**
     * deletes an Employee
     */
    public void deleteAnEmployee(){
        boolean isFound=false;
        this.printBranchEmployees();
        System.out.println("Enter the employee mail you want to fire");
        Scanner input=new Scanner(System.in);
        String mail=input.nextLine();
        try {
            for (int i = 0; i < employeeIterator; i++) {
                if(branchEmployees.get(i).geteMail().equals(mail)){
                	branchEmployees.Remove(i);
                    employeeIterator--;
                }
            }
            if(isFound==false)
                throw new MyException("!ERROR!There are no employee like you searched!ERROR!");
        }catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    public void deleteAnEmployee(boolean x){
        boolean isFound=false;
        this.printBranchEmployees();
        System.out.println("Deleting the first employee");
        branchEmployees.Remove(0);
    }
    public String toString() {//O(n)
    	printBranchEmployees();
    	StringBuilder result = new StringBuilder();
    	result.append("Welcome to ");
    	result.append(getName()+" branch.\n We have:"+branchFurnitures+"\n");
    	result.append("And this employees:"+branchEmployees);
        return result.toString();
    }
}