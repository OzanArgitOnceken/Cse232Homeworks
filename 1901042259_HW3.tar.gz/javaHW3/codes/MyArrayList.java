import java.util.Iterator;
import java.util.ListIterator;

public class MyArrayList<E>{
	private E[] data;
	private int size;
	private int current;
	public MyArrayList() {
		size=1;
		current=0;
		data=(E[])new Object[1];
	}
	/**
	 *	@param index for wanted index
	 *	@return returns wanted data
	 */
	public E get(int index) {
		if(index>size||data[index]==null)
			return null;
		return (E)data[index];
	}
	/**
	 * @param index data wanted to change
	 * @param anEntry new data
	 * @return returns changed data
	 */
	public E set(int index,E anEntry) {
		E firstElement=data[index];
		data[index]=anEntry;
		return firstElement;
	}
	
	/**
	 * @return returns the size of list
	 */
	public int size() {return size;}
	
	/**
	 * @param anEntry data which will add to list
	 * @return returns true every case
	 */
	public boolean add(E anEntry) {
		if(current>=size)
			reallocPlus();
		data[current++]=anEntry;
		return true;
	}
	/**
	 * it adds new data and shifts others
	 * @param index data where wanted to add
	 * @param anEntry data wanted to add
	 */
	public void add(int index,E anEntry) {
		if((current++)>=size)
			reallocPlus();
		for(int i=current-1;i>index;--i)
			data[i]=data[i-1];
		data[index]=anEntry;
		return;
	}
	
	/**
	 * @param anEntry wanted data
	 * @return returns index of data
	 */
	public int indexOf(E anEntry) {
		for(int i=0;i<current;++i)
			if(data[i]==anEntry)
				return i;
		return -1;
	}
	
	/**
	 * @return returns wanted data
	 * @param index index of wanted data
	 */
	public E remove(int index) {
		E returnData=data[index];
		for(;index<current-1;++index)
			data[index]=data[index+1];
		current--;
		if((current-1)<size/2)
			reallocMinus();
		return returnData;
	}

	/**
	 * removes wanted data
	 * @param data finds wanted data
	 */
	public void remove(E data) {
		for(int i=0;i<current-1;++i) {
			if(get(i).equals(data))
				remove(i);
			break;
		}
	}
	
	/**
	 * this method works only when size is less than half of array, for memory efficiency
	 */
	private void reallocMinus(){
		E[]temp=(E[]) new Object[size/2];
		for(int i =0;i<size/2;i++)
			temp[i]=data[i];
		data=temp;
		size/=2;
	}
	/**
	 * this method reallocs the array
	 */
	private void reallocPlus() {
		E []temp=(E[])new Object[size*2];
		for(int i=0;i<size;++i) {
			temp[i]=data[i];
		}
		data=temp;
		size*=2;
	}
	/**
	 * Iterator class
	 */
	private class MyIterator implements ListIterator<E>{
		
		private int current;
		
		public MyIterator(){
			setCurrent(0);
		}
		
		@Override
		public boolean hasNext() {
			return current<size&&data[current]!=null;
		}

		@Override
		public E next(){
			if(hasNext())
			{
				return (E) data[current++];
			}
			return null;
		}
		public int getCurrent() {
			return current;
		}
		public void setCurrent(int current) {
			this.current = current;
		}
		@Override
		public boolean hasPrevious() {
			return current>=1;//if current =1 it has previous
		}
		@Override
		public E previous() {
			if(hasPrevious())
				return (E)data[current--];
			return null;
		}
		@Override
		public int nextIndex() {
			if(hasNext())
				return current+1;
			return -1;
		}
		@Override
		public int previousIndex() {
			if(hasPrevious())
				return current-1;
			return -1;
		}
		@Override
		public void remove() {
			MyArrayList.this.remove(current);
		}
		@Override
		public void set(E e) {
			data[current]=e;
			
		}
		@Override
		public void add(E e) {
			MyArrayList.this.add(current,e);
			
		}
	}
	public Iterator<E> iterator() {
		return new MyIterator();
	}
	/**
	 * override of toString method
	 */
	public String toString() {
		return recursiveToString(0);
	}
	/**
	 * @return returns String recursively
	 * @param for recursive (commonly sended 0 but if sended another integer it starts from there)
	 */
	private String recursiveToString(int i) {
		if(i==current)
			return "||";
		else {
			return data[i].toString()+"=>"+recursiveToString(++i);
		}
	}

	/**
	 * @return compares two data and returns true if they are same
	 */
	public boolean contains(E compared) {
		for(int i=0;i<size;++i) {
			if(data[i].equals(compared))
				return true;
		}
		return false;
	}

}