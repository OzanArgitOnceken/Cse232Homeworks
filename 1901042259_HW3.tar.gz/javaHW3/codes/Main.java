import java.util.Scanner;

public class Main {
    public static void main(String[] args){
    Admin ozan=new Admin(true);
	ozan.addBranch("Kartal");
	ozan.addBranch("Eryaman");
	for(int i=0;i<30;++i) {
    	ozan.addFurnitureByBranchName("Kartal",new Furniture());
	}
	ozan.addEmployeeToBranchByName("Kartal", new Employee(true));
	ozan.addEmployeeToBranchByName("Kartal", new Employee(true));
	ozan.addBranch("Güzelyalı");
	ozan.deleteBranch("Eryaman");
	ozan.addEmployeeToBranchByName("Güzelyalı",new Employee(true));
	ozan.deleteBranch("Güzelyalı");
	ozan.fireAnEmployee("Kartal");//it should be 2 employee but admin fire one so there are 1 employee in kartal
	System.out.println("Now printing all admin datas.");
	System.out.println(ozan);
	Branch branch=new Branch("Temporary");
	Customer customer=new Customer(true);
	branch.addFurniture(new Furniture());
	branch.addFurniture(new Furniture());
	branch.addFurniture(new Furniture());
	branch.addFurniture(new Furniture());
	System.out.println("This is temporary branches datas");
	System.out.println(branch);
	System.out.println("This is temporary customer datas");
	System.out.println(customer);
	
	System.out.println("I am asking basic furniture:");
	System.out.println(ozan.askFurniture(new Furniture()));
	
	Customer x=new Customer(true);
	x.addOrder(new Furniture());
	x.addOrder(new Furniture());
	x.deliverOrder(new Furniture());
	System.out.println(x);
	System.out.println(x);
	System.out.println("***************************************");
    AutomationSystem webSite=new AutomationSystem();
    while(webSite.Menu()){}
    System.out.println("Now try for polymorphsim");
    polymorphism(new Admin());
    polymorphism2(new Admin());
    polymorphism2(new Employee());
    }
    /**
     * it is for test polymorphism
     * @param x takes person class and behaves like admin ,customer or employee
    */
    public static void polymorphism(Person x){
        x.Print();
    }
    /**
     * @param x takes seller interface and behaves like admin or employee
     */
    public static void polymorphism2(Seller x){
        x.printFurnituresWeHave();
    }
}