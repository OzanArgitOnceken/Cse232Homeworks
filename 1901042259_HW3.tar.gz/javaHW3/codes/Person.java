import java.util.Scanner;

abstract class Person {
    private static int id=1000;
    private String name;
    private String surname;
    private int personal_id;
    private String eMail;
    private String password;
    private boolean created=false;
    private String role;
    private String phone_number;
    private String adresString;
    /**
     * This is a constructor
     * @param role it is Role string like "Admin","Customer" or "Employee"
    */
    public Person(String role){
        Scanner input=new Scanner(System.in);
        System.out.println("This is a "+role+" creation screen:");
        setRole(role);
        System.out.println("Enter name:");
        this.name=input.nextLine();
        System.out.println("Enter surname:");
        this.surname=input.nextLine();
        System.out.println("Enter e-Mail:");
        this.eMail=input.nextLine();
        System.out.println("Enter password:");
        this.password=input.nextLine();
        System.out.println("Enter phone number:");
        this.phone_number=input.nextLine();
        System.out.println("Enter adress:");
        this.adresString=input.nextLine();
        created=true;
        personal_id=id;
        id++;
    }
    
    public Person(String role,boolean x) {//boolean for driver class
    	this.role=role;
        setRole(role);
        this.name="Suat";
        this.surname="Mutlu";
        this.eMail="sm";
        this.password="sm";
        this.phone_number="05446128956";
        this.adresString="Kartal marmaray durağı";
        created=true;
        personal_id=id;
        id++;
    	
    }

    /**
     * Constructor
     * @param i if undefined and not created person coder should send int
    */
    public Person(int i){
        setRole("Person");
        setName("Undefined");
        setSurname("Undefined");
        seteMail("Undefined@gmail.com");
        setPassword("NULL");
        setCreated(false);
    }
    /**
     * 
     * @param name 
     * @param surname
     * @param eMail
     * @param password
    */
    public Person(String name,String surname,String eMail,String password){
        setName(name);
        setSurname(surname);
        setPassword(password);
        seteMail(eMail);
        setAdress("adress");
        setPhoneNumber("0544612");
        setCreated(true);
    }

    private void setPhoneNumber(String phoneNumber){
        this.phone_number=phoneNumber;
    }

    private void setAdress(String adress){
        this.adresString=adress;
    }

    private void setPassword(String password){
        this.password=password;
    }

    private void setRole(String role){
        this.role=role;
    }

    private void seteMail(String eMail){
        this.eMail=eMail;
    }

    private void setName(String name){
        this.name=name;
    }

    private void setSurname(String surname){
        this.surname=surname;
    }

    private void setCreated(boolean created){
        this.created=created;
    }

    public String getName(){
        return this.name;
    }

    public String getSurname(){
        return this.surname;
    }

    public int getPersonalId(){
        return this.personal_id;
    }

    public String geteMail(){
        return this.eMail;
    }

    public String getPassword(){
        return this.password;
    }

    public boolean getCreated(){
        return this.created;
    }

    public String getRole(){
        return this.role;
    }

    public String getPhoneNumber() {
        return this.phone_number;
    }

    public String getAdress() {
        return this.adresString;
    }
    /**
     * prints all details about person
     */
    void Print(){
        System.out.println("My name:"+getName());
        System.out.println("My surname:"+getSurname());
        System.out.println("My id:"+getPersonalId());
        System.out.println("Email:"+geteMail());
        System.out.println("Password:"+getPassword());
        System.out.println("My role:"+getRole());
        System.out.println("Phone number:"+getPhoneNumber());
        System.out.println("Adress:"+getAdress());
        if(this.created)
            System.out.println("I am created before");
        else
            System.out.println("I am not created before");
    }
    public String toString() {
            System.out.println("My name:"+getName());
            System.out.println("My surname:"+getSurname());
            System.out.println("My id:"+getPersonalId());
            System.out.println("Email:"+geteMail());
            System.out.println("Password:"+getPassword());
            System.out.println("My role:"+getRole());
            System.out.println("Phone number:"+getPhoneNumber());
            System.out.println("Adress:"+getAdress());
            if(this.created)
                System.out.println("I am created before");
            else
                System.out.println("I am not created before");
            return " ";
        }
}