public class Admin extends Person implements Seller {
    private MyDoubleLinkedList<Branch> branches;
    private int branch_iterator;
    /**
     * All constructors send the role to the Person class and it is automatically setted
     * and other things are setting with inputs
     */
    public Admin(){
        super("Admin");
    	branches=new MyDoubleLinkedList<Branch>();
    }
    public Admin(boolean x) {
    	super("Admin",true);
    	branches=new MyDoubleLinkedList<Branch>();
    }
    /**
     * This method prints all branch details and admins personal informations
     */
    
    public int getBranch_Iterator(){
        return this.branch_iterator;
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    /**
     * 
     * @param branchName takes string name of branch
     * @return returns branch
    */
    public Branch getBranch(String branchName){
        for (int i = 0; i < branch_iterator; i++) {
            if(branchName.equals(branches.get(i).getName())){
                return branches.get(i);
            }
        }
        return new Branch("There is no branch like you searched");
    }
    
    /**
     * @param name takes any string name and creates new branch
    */
    public void addBranch(String name){
        branches.add(new Branch(name));
        ++branch_iterator;
    }

    /**
     * 
     * @param addingBranch takes any branch and adds it to the array
    */
    public void addBranch(Branch addingBranch){
        branches.add(addingBranch);
        ++branch_iterator;
    }
    
    /**
     * creates a branch and adds to array
     */
    public void addBranch(){
        branches.add(new Branch());
        ++branch_iterator;
    }
    
    /**
     * 
     * @param name string branch name
     * @param maxFurnitureNumber max furniture number for memory allocating
     * @param maxEmployee max employee number for memory allocating
    */
    public void addBranch(String name,int maxFurnitureNumber,int maxEmployee){
        branches.add(new Branch(name,maxFurnitureNumber,maxEmployee));
        ++branch_iterator;
    }
    
    /**
     * @param branchName takes string branch name and send delete request for branch
     */
    public void fireAnEmployee(String branchName){
    for (int i = 0; i < branch_iterator; i++) {
        if(branches.get(i).getName().equals(branchName))
            branches.get(i).deleteAnEmployee(true);
        }
    }
    /**
     * @param branchName deletes branch
     */
    public void deleteBranch(String branchName){
        branch_iterator--;
        for (int i = 0; i < branch_iterator; i++) {
            if(branches.get(i).getName().equals(branchName)){
            	System.out.println("branch name:"+branches.get(i).getName());
            	branches.Remove(i);
            }
        }
    }

    /**
     * 
     * @param branchName branch's name(string)
     * @param tempFurniture furniture to add
    */
    public void addFurnitureByBranchName(String branchName,Furniture tempFurniture){
        for (int i = 0; i <branch_iterator; i++){
            if((branches.get(i)).getName().equals(branchName)) {
                (branches.get(i)).addFurniture(tempFurniture);
            }
        }
    }

    /**
     * prints all furnitures
     */
    @Override
    public void printFurnituresWeHave() {
        for (int i = 0; i < branch_iterator; i++) {
            branches.get(i).printFurniture();
        }
    }
    /**
     * asks furniture if exists in all branches
     * @param orderedFurniture furniture for search
     */
    @Override
    public boolean askFurniture(Furniture orderedFurniture) {//O(k^2m)
        for (int i = 0; i < branch_iterator; i++) {//O(k)
            if(branches.get(i).haveFurniture(orderedFurniture)){//O(klm)
                return true;
            }
        }
        return false;
    }

    /**
     * 
     * @param searchFurniture furniture for search
     * @return returns branch that searched furniture exists on
     * if furniture does not exists throws exception
    */
    public Branch whichBranch(Furniture searchFurniture){//ok^3lm
        
        try {
            for (int i = 0; i < branch_iterator; i++) {//ok
                if(branches.get(i).haveFurniture(searchFurniture)){//Oklm
                    return branches.get(i);//ok
                }
            }
            throw new MyException("No furnitures like you searched");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return new Branch("Temporary Error Branch");
        }
    }

    /**
     * @param tempEmployee searching employee
     * @return returns Branch that employee exists
    */
    public String getEmployeesBranch(Employee tempEmployee){
        try{
            for (int i = 0; i < branch_iterator; i++) {//n
                if(branches.get(i).isEmployeeWorksHere(tempEmployee))//klmn
                    return branches.get(i).getName();//On+1
            }
            throw new MyException("No employee found like your search");
        }catch(Exception e){
            System.out.println(e.getMessage());
            return "Wrong Branch";
        }
    }
    public String toString() {//on
    	return branches.toString();
    }
    /**
     * 
     * @param branchName takes branch name string
     * @param temp takes employee object and adds to the array
    */
    public void addEmployeeToBranchByName(String branchName,Employee temp){
        for (int i = 0; i < branch_iterator; i++) {//O(n)
            if(branches.get(i).getName().equals(branchName)) //O(n)*O(p)
                branches.get(i).addEmployee(temp);//O(n)+O(k^2)
        }
    }
}