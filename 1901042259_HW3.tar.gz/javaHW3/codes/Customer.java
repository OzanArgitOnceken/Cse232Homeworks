import java.util.Scanner;

public class Customer extends Person{
    private MyHybridList<Furniture>orders;
    boolean logged;
    int order_iterator;
    /**
     * This is a constructor
     * This constructor sets max memory of array order to 20
     * and sets order_iterator to 0
     */
    public Customer() {
        super("Customer");
        orders=new MyHybridList<Furniture>();
        this.logged=false;
        order_iterator=0;
    }
    public Customer(boolean x) {
        super("Customer",true);
        orders=new MyHybridList<Furniture>();
        this.logged=false;
        order_iterator=0;
    }

    /**
     * This method prints all customer orders(Furnitures)
     */
    public void printCustomerOrders(){
    	System.out.println(orders);
    }

    public int getOrderIterator(){
        return this.order_iterator;
    }

    /**
     * This method deletes delivered furniture from customer's order array
     * @param deliveredFurniture delivered order 
    */
    public void deliverOrder(Furniture deliveredFurniture){
       if(orders.contains(deliveredFurniture))
           orders.remove(deliveredFurniture);
    }
    /**
     * This method allows to customer for ask furniture on any branch
     * 
     * @param furnitureForSearch a furniture for search
     * @param branchForSearch a branch object for search
     * @return returns true if furniture founded
    */
    public boolean askFurniture(Furniture furnitureForSearch,Branch branchForSearch){
        if(branchForSearch.haveFurniture(furnitureForSearch))
            return true;
        return false;
    }

    /**
     * This method adds new order to customer's order array 
     * @param newFurnitureOrder furniture that wanted from customer
    */
    public void addOrder(Furniture newFurnitureOrder)
    {
        orders.add(newFurnitureOrder);
        order_iterator++;
    }

    /**
     * this method sends first order
     * it makes easy to sell orders
     * @return returns the order[0]
    */
    public Furniture sendFirstOrder(){
        return orders.get(0);
    }

    /**
     * This method decreases order iterator
     */
    public void decreaseOrderIterator(){
        this.order_iterator--;
    }

    /**
     * This method helps to find a furniture
     * @param searcherAdmin Admin for ask some furniture
     * @return returns the branch that furniture exists on branch
    */
    public Branch onWhichBranch(Admin searcherAdmin){//ok^3lm
        System.out.println("Enter the furniture or search your first order(for first order enter -1)");
        Scanner input=new Scanner(System.in);      
        int choice=input.nextInt();
        input.nextLine();
        if(choice==-1)
            return searcherAdmin.whichBranch(sendFirstOrder());//ok^3lm
        else
            return searcherAdmin.whichBranch(new Furniture());//ok^3lm
    }
    public String toString() {
        return orders.toString()+"\n";
    }
}