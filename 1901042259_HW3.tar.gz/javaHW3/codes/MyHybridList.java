public class MyHybridList<E> {
	private Node <E>head;
	private Node <E>last;
	private int size;
	private static int max_array_size=20;
	/**
	 * sets size=0
	 * last and first node to null
	 */
	public MyHybridList() {
		this.head=null;
		last=null;
		size=0;
	}
	/**
	 * @param data wanted to add
	 * @return returns true every case
	 */
	public boolean add(E data) {
		if(head==null) {
			head=new Node(data,null,null);
			last=head;
		}
		else {
			if(last.array.size()==max_array_size-1) {
				last.next=new Node(data,last,null);
				last=last.next;
			}
			else {
				last.array.add(data);
			}
		}
		size++;
		return true;
	}
	
	/**
	 * @param data removes sended data
	 */
	public void remove(E data) {//On
		Node temp=head;
		while(temp.next!=null) {
			if(temp.array.contains(data))
				temp.array.remove(data);
				temp=temp.next;
		}
	}
	/**
	 * @param index removes sended index
	 */
	public void remove(int index) {
		int border=index/max_array_size;
		Node temp=head;
		int i=0;
		while(temp.next!=null&&i<border){
			++i;
			temp=temp.next;
		}
		if(i==border) {
			temp.prev.next=temp.next;
			temp.next.prev=temp.prev;
		}
		temp.array.remove(index%max_array_size);
	}
	private class Node<E>{
		protected MyArrayList<E> array;
		private Node <E>next;
		private Node <E>prev;
		public Node(E data,Node prev,Node next){
				array=new MyArrayList();
				array.add(data);
				this.next=next;
				this.prev=prev;
		}
		public Node(){
			array=new MyArrayList();
			this.next=null;
			this.prev=null;
		}
		/**
		 * @param data for existed node 
		 */
		public void add(E data) {
			array.add(data);
		}
	}
	/**
	 * @return returns string for System.out.println();
	 */
	public String toString(){//On
		Node tempNode=head;
		StringBuilder temp=new StringBuilder();
		while(tempNode!=null) {
			temp.append(tempNode.array);
			temp.append("\n------------\n");
			tempNode=tempNode.next;
		}
		return temp.toString();
	}
	
	/**
	 * @param data for look if it exists
	 * @return returns true if it exists
	 */
	public boolean contains(E data) {	//On
		Node<E> temp=head;
		while(temp.next!=null) {
			if(temp.array.contains(data)){
				return true;
			}
			temp=temp.next;
		}
		return false;
	}
	/**
	 * @param index for search
	 * @return returns wanted data
	 */
	public E get(int index){
		int listShifter=index/max_array_size;
		Node temp=head;
		for(int i=1;i<listShifter;++i) {
			temp=temp.next;
		}
		return (E) temp.array.get(index%max_array_size);
	}
}