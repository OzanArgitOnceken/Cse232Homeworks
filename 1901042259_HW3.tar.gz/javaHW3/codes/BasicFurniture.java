public interface BasicFurniture {
    void setModel(int model);
    void setColor(int color);
    int getModel();
    int getColor();
    public boolean equals(BasicFurniture t);
}
