    import java.util.Scanner;

    public class AutomationSystem {
        private Customer customers[];
        private Admin admin;
        private Employee employees[];
        private int customer_iterator;
        private int employee_iterator;
        public AutomationSystem(){
            customers=new Customer [20];
            employees=new Employee[20];
            customer_iterator=0;
            employee_iterator=0;
            this.admin=new Admin();
        }
        /**
         * adds admin
         * @param admin admin object
        */
        public void addAdmin(Admin admin){
            this.admin=admin;
        }
        
        /**
         * 
         */
        public void addAdmin(){
            this.admin=new Admin();
        }

        /**
         * 
         * @param addingCustomer customer object for add
        */
        private void addCustomer(Customer addingCustomer){
            this.customers[customer_iterator++]=addingCustomer;
        }

        /**
         * 
         */
        public void addCustomer(){
            this.customers[customer_iterator++]=new Customer();
        }


        /**
         * 
         * @param addingEmployee adding Employee object
        */
        public void addEmployee(Employee addingEmployee){
            this.employees[employee_iterator++]=addingEmployee;
        }
        /**
         * 
         */
        public void addEmployee(){
            this.employees[employee_iterator++]=new Employee();
        }
        /**
         * Menu for crete profile or login
         */
        public boolean Menu(){
            Scanner inputScanner = new Scanner(System.in);
            System.out.println("Choose operation");
            System.out.println("1- Login");
            System.out.println("2- Create account(This menu gives permission to create only Customer because");
            System.out.println("one admin is enough and employees should create by admin and send a branch otherwise");
            System.out.println("employees are like unemployed)");
            System.out.println("Another number for exit");
            int choice=inputScanner.nextInt();
            inputScanner.nextLine();
            if(choice==1){
                String temporary;
                System.out.println("Enter eMail:");
                System.out.println("!EMAIL!");
                temporary=inputScanner.nextLine();
                if(admin.geteMail().equals(temporary)){ 
                    System.out.println("System find an admin name "+temporary+" please enter the password");
                    temporary=inputScanner.nextLine();
                    if(admin.getPassword().equals(temporary))
                        AdminMenu();
                }
                else
                {
                    boolean finded_at_employee=false;
                    for (int i = 0; i < employee_iterator; i++) {
                        if(employees[i].geteMail().equals(temporary))
                            {
                                System.out.println("System find an employe name "+temporary+" please enter the password");
                                temporary=inputScanner.nextLine();
                                if(employees[i].getPassword().equals(temporary))
                                    EmployeeMenu(employees[i]);
                            }
                    }
                    if(!finded_at_employee){
                        for (int j = 0; j < customer_iterator; j++){
                            if(customers[j].geteMail().equals(temporary)){
                                System.out.println("System find an customer name "+temporary+" please enter the password");
                                temporary=inputScanner.nextLine();
                                if(customers[j].getPassword().equals(temporary))
                                    CustomerMenu(customers[j]);
                                }
                        }
                    }
                }
                return true;
            }
            else if(choice==2){
                System.out.println("User(Customer)");
                    addCustomer();
                return true;
            }
            return false;
        }

        /**
         * for do all admin work
         */
        private void AdminMenu(){
            System.out.println("Welcome to Admin menu");
            System.out.println("What you will do?\n1-Add branch");
            System.out.println("2-Add employee to branch");
            System.out.println("3-Do we have this furniture?");
            System.out.println("4- Add furniture on branch");
            System.out.println("5-Print all details");
            System.out.println("6- Delete branch");
            System.out.println("7- Fire an employee");
            Scanner inputScanner=new Scanner(System.in);
            int choice=inputScanner.nextInt();
            inputScanner.nextLine();
            if(choice==1){
                System.out.println("Enter branch name");
                admin.addBranch();
            }
            else if(choice==2){
                System.out.println("Create an employee");
                Employee tempEmployee=new Employee();
                System.out.println("\n\n\n\n\nEnter branch name");
                admin.addEmployeeToBranchByName(inputScanner.nextLine(), tempEmployee);
                addEmployee(tempEmployee);
            }
            else if(choice==3){
                if(admin.askFurniture(new Furniture())){
                    System.out.println("Yes we have that furniture");
                }
                else
                    System.out.println("No we do not have that furniture");
            }
            else if(choice==4){
                System.out.println("Enter Branch name");
                createFurnitureAdminToBranch(inputScanner.nextLine());
            }
            else if(choice==5)
                admin.Print();
                else if(choice==6){
                    System.out.println("Enter branch name you want to delete");
                    admin.deleteBranch(inputScanner.nextLine());}
                else if(choice==7){
                    System.out.println("Enter branch name you want to fire an employee");
                    admin.fireAnEmployee(inputScanner.nextLine());
                }
        }

        /**
         * 
         *  for do all admin work
         * @param aCustomer Created customer object
        */
        private void CustomerMenu(Customer aCustomer){
            System.out.println("Welcome to Customer menu");
            System.out.println("1-Add order");
            System.out.println("2-Buy first order");
            System.out.println("3-Buy all orders on Branch");
            System.out.println("4- Print all details");
            System.out.println("5- Search products");
            System.out.println("6- Search branch for furniture");
            Scanner input=new Scanner(System.in);
            int choice=input.nextInt();
            input.nextLine();
            if(choice==1){
                System.out.println("Enter furniture's class,model and color\nExample:\nChair\n1\n1");
                aCustomer.addOrder(new Furniture(input.nextLine(),input.nextInt(),input.nextInt()));
                input.nextLine();
            }
            else if(choice==2){
                System.out.println("Enter branch name");
                Branch tempBranch=admin.getBranch(input.nextLine());
                tempBranch.sellFurniture(aCustomer.sendFirstOrder());
                if(tempBranch.sellFurniture(aCustomer.sendFirstOrder())){
                    aCustomer.deliverOrder(aCustomer.sendFirstOrder());
                }
            }
            else if(choice==3){
                System.out.println("Enter branch name");
                Branch tempBranch=admin.getBranch(input.nextLine());
                for (int i = 0; i <= admin.getBranch_Iterator(); i++) {
                    tempBranch.sellFurniture(aCustomer.sendFirstOrder());
                    if(tempBranch.sellFurniture(aCustomer.sendFirstOrder())){
                        aCustomer.deliverOrder(aCustomer.sendFirstOrder());
                    }
                }
            }
            else if(choice==4){
                aCustomer.Print();
                aCustomer.printCustomerOrders();
            }
            else if(choice==5){
                System.out.println("Enter branch you want to search");
                Branch temp=admin.getBranch(input.nextLine());
                System.out.println("Enter the furniture informations that you want:");
                aCustomer.askFurniture(new Furniture(), temp);
            }
            else if(choice==6){
                    Branch tempBranch=aCustomer.onWhichBranch(admin);
                    tempBranch.printBranch();
                }
        }

        private void EmployeeMenu(Employee anEmployee){
            System.out.println("Welcome to Employee menu");{
                System.out.println("1-Ask Furniture on the Branch");
                System.out.println("2-Print furnitures on branch");
                System.out.println("3-Customer registiraton");
                System.out.println("4-Add furniture on Branch");
                System.out.println("5-Print a customer");
                System.out.println("6-Delete Furniture order of any customer");
                Scanner inputScanner=new Scanner(System.in);
                int choice=inputScanner.nextInt();
                inputScanner.nextLine();
                if(choice==1){
                    if(anEmployee.askFurniture(new Furniture()));
                }
                else if(choice==2)
                    anEmployee.printFurnituresWeHave();
                else if(choice==3)
                    addCustomer();
                else if(choice==4){
                        admin.addFurnitureByBranchName(admin.getEmployeesBranch(anEmployee), anEmployee.addFurniture());
                    }
                else if(choice==5)
                {
                    System.out.println("enter mail of customer for search a customer");
                    String name=inputScanner.nextLine();
                    for (int i = 0; i < customer_iterator; i++) {
                        if(name.equals(customers[i].geteMail()))
                            anEmployee.printCustomer(customers[i]);
                    }
                }
                else if(choice==6){
                        admin.addFurnitureByBranchName(admin.getEmployeesBranch(anEmployee), anEmployee.addFurniture());
                    }
                    
            }
        }
        /**
         * 
         * @param branchString branch name(string)
        */
        private void createFurnitureAdminToBranch(String branchString){
            Scanner input=new Scanner(System.in);
            System.out.println("Choose model");
            int model,color;
            model=input.nextInt();
            System.out.println("Choose color");
            color=input.nextInt();
            input.nextLine();
            System.out.println("Enter your choice");
            System.out.println("Bookcase");
            System.out.println("Cabinet");
            System.out.println("Chair");
            System.out.println("Meeting Table");
            System.out.println("Office Desk");
            admin.addFurnitureByBranchName(branchString,new Furniture(input.nextLine(),model,color));

        }
        /*
        
        public void Driver(){
            admin=new Admin("Sam","Serious","SamSery","1234");
        }
        */
    }